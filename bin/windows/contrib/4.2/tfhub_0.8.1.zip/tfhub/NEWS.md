# tfhub 0.8.1

- `install_tfhub()` now defaults to the release version of tensorflow_hub.
- Removed {pins} dependency

# tfhub 0.8.0

* Added a `NEWS.md` file to track changes to the package.
