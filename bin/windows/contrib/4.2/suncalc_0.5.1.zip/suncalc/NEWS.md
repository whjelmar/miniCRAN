# suncalc 0.5.1 (2022-09-28)

* Update maintener

# suncalc 0.5 (2019-04-02)

## Major changes 
* Full R implementation of all functions

## Bugfixes
* getSunlightTimes & getMoonTimes always return Date (rather than Date + 12:00:00...)

# suncalc 0.4 (2018-02-22)

## Bugfixes
* Dates with times before a certain time return times for previous day. See https://github.com/mourner/suncalc/issues/11

# suncalc 0.3 (2017-10-04)

## Bugfixes
* Dates with times before a certain time return times for previous day. See https://github.com/mourner/suncalc/issues/11

# suncalc 0.2 (2017-09-08)

## Bugfixes
* Keeping only one variable in all functions
