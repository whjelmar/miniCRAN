VARselect(Canada, lag.max = 8, type = "both")
