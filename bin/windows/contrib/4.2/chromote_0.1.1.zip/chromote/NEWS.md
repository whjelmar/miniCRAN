# chromote 0.1.1

* Update docs for CRAN (#93)


# chromote 0.1.0

* Initial package release
