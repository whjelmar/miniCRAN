# ggimg 0.1.0

Completed general API, documentation, and unit testing for the package's two
main functions: `geom_point_img` and `geom_rect_img`.
