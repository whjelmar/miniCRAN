# chronicler

# chronicler 0.2.0

## New features

* First CRAN release
