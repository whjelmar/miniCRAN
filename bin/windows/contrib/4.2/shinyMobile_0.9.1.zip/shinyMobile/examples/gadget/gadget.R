library(shiny)
runGadget(shinyAppDir(system.file("examples/tab_layout", package = "shinyMobile")))
