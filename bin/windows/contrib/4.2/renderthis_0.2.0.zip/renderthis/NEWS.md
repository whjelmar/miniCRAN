# renderthis 0.2.0

- Addresses several previous issues related to a note about a Crashpad file being generated from CI checks on Ubuntu.
- Implements initial support for rendering Quarto revealjs presentations.

# renderthis 0.1.1

- Fixes a bug (#63) by checking that the path returned by find_chrome() actually exists.

# renderthis 0.1.0

* Initial version, most functionality copied / modified from v0.0.9 of xaringanBuilder
* Added a `NEWS.md` file to track changes to the package.
