# operator.tools 1.6.2

* #1: Move .initOps to .onLoad. (Thanks, Hong-Revo) 

# operator.tools 1.6.0

* Bump version to 1.6.0 to match *formula.tools* package
* Update README.md
* Update man
* Add support for *magrittr* and *pipeR* opertors
* Added a `NEWS.md` file to track changes to the package.



