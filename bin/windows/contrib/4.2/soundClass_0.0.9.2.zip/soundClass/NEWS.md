# soundClass 0.0.9

First public release.

# soundClass 0.0.9.1

- Bug fix in overlap parameter of function spectro_calls(). Now
accepts values of 0.5 and 0.75

- Include progress bar in console for function spectro_calls()

- Update bundled model code

- Update download link of example files
 
# soundClass 0.0.9.2

- Bug fix in the window size parameter of function spectro_calls(). The
y-axis values of the spectrograms generated are now correct

- Bug fix in metadata parameter of function auto_id(). The function
now reads the file path correctly

- Added checkbox input for Butterworth filter in app_label()

- Minor updates in the documentation

