# fpp3 (0.4)

  * Added bank_calls, prices, souvenirs and insurance data sets from fpp2
  * Added Australian accommodation data
  * Added aus_passengers data
  * Increased minimum versions for some package dependencies

# fpp3 0.3
 
  * Updated all objects to work with tsibble v0.9.0
  * Added series titles to us_employment

# fpp3 0.2

 * Added aus_arrivals data set.

# fpp3 0.1

 * Initial version based on the tidyverse package by Hadley Wickham.
 * Some data ported from fpp2. New data sets include us_employment.
