# xplorerr 0.1.2

This is a patch release to fix CRAN note about lazy data.

# xplorerr 0.1.1

This is a patch release to fix bugs in the app.

- Check suggested packages ([#14](https://github.com/rsquaredacademy/xplorerr/issues/14))
- Screening error ([#16](https://github.com/rsquaredacademy/xplorerr/issues/16))

# xplorerr 0.1.0

First release



