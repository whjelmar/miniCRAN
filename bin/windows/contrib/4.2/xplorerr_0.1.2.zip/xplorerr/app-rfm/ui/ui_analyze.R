navbarMenu('Analyze', icon = icon('search-plus'),

	source('ui/ui_home.R', local = TRUE)[[1]],
  source('ui/ui_rfm.R', local = TRUE)[[1]],
  source('ui/ui_segment.R', local = TRUE)[[1]]

)
