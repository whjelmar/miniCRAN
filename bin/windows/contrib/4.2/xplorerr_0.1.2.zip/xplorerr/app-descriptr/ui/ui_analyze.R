navbarMenu('Analyze', icon = icon('search-plus'),
  source('ui/ui_eda.R', local = TRUE)[[1]]
)
