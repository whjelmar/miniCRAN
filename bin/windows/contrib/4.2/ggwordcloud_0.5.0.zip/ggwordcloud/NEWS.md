# ggwordcloud 0.5.0
* Novelties:
   * x2 speedup
* Bug fix:
   * fix a out of bounds issue

# ggwordcloud 0.4.0
* Novelties:
    * New thank you word list thanks to Enrico Spinielli
    * Use png instead of Cairo
    * New show_boxes option to visualize the bounding boxes used in the placement algorithm
* Bug fixes
    * add missing parse_safe function
    * fix a bug when using only one box size

# ggwordcloud 0.3.0
* Novelties:
    * documentation with a lovely example
    * new mask and shape parameters
    * better replacement by using the right scale
* Bug fixes:
    * workaround for a Cairo issue with some utf8 strings
    * geom_wordcloud_area works even if no sizes are given

# ggwordcloud 0.2.0
* add the rm_outside option
* wordcloud layout acceleration thanks to better word boxing
* wordcloud and wordcloud2 approximate replacements

# ggwordcloud 0.1.0
* Initial version
