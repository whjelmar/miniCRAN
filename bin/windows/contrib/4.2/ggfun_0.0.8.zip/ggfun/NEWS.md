# TODO

+ mv facet utilities from `ggtree`
+ mv `theme_fp` from ggbreak


# ggfun 0.0.8

+ compatible with ggplot2 v3.4.0 (2022-11-07, Mon)

# ggfun 0.0.7

+ add `theme_stamp` (2022-08-31, Wed, #6)

# ggfun 0.0.6

+ mv `identify.gg()` from 'ggtree' (2022-04-01, Fri)
+ mv `ggrange()`, `xrange()` and `yrange()` from 'aplot'

# ggfun 0.0.5

+ mv `theme_transparent()` and `theme_nothing()` from the ggimage package (2022-01-20, Thu)

# ggfun 0.0.4

+ mv `ggbreak2ggplot`, `is.ggbreak` and `is.ggtree` from the aplot package (2021-09-16, Thu)
+ `facet_set`: a better implementation of manually setting facet label, which combines `add_facet`, `ggtree::facet_labeller`  and more (2021-09-15, Wed)
+ `add_facet` to add facet label to a ggplot object (2021-09-03, Fri)

# ggfun 0.0.3

+ `element_roundrect` to add round rect background to ggplot legend. Now we can use `theme()` to enable this effect (2021-08-10)

# ggfun 0.0.2

+ mv `gglegend` and `set_font` functions from `yyplot` package (2021-06-30)
+ mv `get_aes_var` from `rvcheck` package

# ggfun 0.0.1

+ `keybox` to add round rect background to ggplot legend (2021-06-29)

