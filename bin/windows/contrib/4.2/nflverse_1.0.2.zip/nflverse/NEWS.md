# nflverse 1.0.2

* `nflverse_update()` includes the nflverse package.
* improved installation instructions for `nflverse_update(devel = TRUE)`

# nflverse 1.0.1

* fixed output of `nflverse_update(devel = TRUE)`

# nflverse 1.0.0

* Initial release.
