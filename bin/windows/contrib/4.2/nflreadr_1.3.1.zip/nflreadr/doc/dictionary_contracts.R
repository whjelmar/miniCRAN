## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  echo = FALSE,
  comment = "#>"
)

## -----------------------------------------------------------------------------
knitr::kable(nflreadr::dictionary_contracts)

