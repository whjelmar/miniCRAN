# spooky 1.0.0

* Added a `NEWS.md` file to track changes to the package.

# spooky 1.1.0
* Fixed an error in the calculation of the confidence interval.

# spooky 1.2.0
* Besides continuous variables, dntroduced metrics and representations suitable for predicting discrete events.


# spooky 1.3.0
* Fixed a bug in quantile graph representation.


# spooky 1.4.0
* Rationalization and streamlining of processes.
