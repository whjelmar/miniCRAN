# riskmetric 0.1.2

- Hotfix release to correct testing suite such that tests are less continent on
  assumptions of locally installed packages, addressing build issues on CRAN
  builders. (#223, @elimillera)

# riskmetric 0.1.1

- Fixing a bug with subclassing of `pkg_ref` objects using the new concrete
  constructors. (#208, @dgkf)

# riskmetric 0.1.0

- Initial version.
- Added a `NEWS.md` file to track changes to the package.
