# ggparliament 2.0.0 
## 09/2018

  - rewritten package from ground up to replace original functions developed by Thomas Leeper
  - vignettes for various functions added
  - initial submission to CRAN