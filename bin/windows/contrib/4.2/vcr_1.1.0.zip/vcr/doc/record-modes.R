## ----echo=FALSE---------------------------------------------------------------
knitr::opts_chunk$set(
    comment = "#>",
    collapse = TRUE,
    warning = FALSE,
    message = FALSE
)

