# prompter 1.1.0

* Fix "permanent" option (#2)
* Update `hint.css` to 2.7.0
* Add "arrow" and "shadow" options

# prompter 1.0.0

* First version
