
    static void %method_name%() {
        bool saveOK = EditorSceneManager.SaveScene(EditorSceneManager.GetActiveScene(), "Assets/Scenes/%scene_name%.unity");
    }
