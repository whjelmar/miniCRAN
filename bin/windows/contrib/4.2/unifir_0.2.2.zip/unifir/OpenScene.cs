
    static void %method_name%() {
        EditorSceneManager.OpenScene("Assets/Scenes/%scene_name%.unity");
    }
