# rapidoc 8.4.3

- Adds support for RapiDoc 8.4.3


# rapidoc 8.4.2

- Adds support for RapiDoc 8.4.2


# rapidoc 8.4.0

- Adds support for RapiDoc 8.4.0


# rapidoc 8.3.0

- Adds support for RapiDoc 8.3.0


# rapidoc 8.1.2

- Adds support for RapiDoc 8.1.2


# rapidoc 8.1.1

- Adds support for RapiDoc 8.1.1
