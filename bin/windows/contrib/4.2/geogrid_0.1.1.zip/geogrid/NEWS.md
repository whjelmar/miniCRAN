# geogrid 0.1.1

* **sf** enhancements and README update

# geogrid 0.1.1

* Add a support for the **sf** objects

# geogrid 0.1.0

* Added a `NEWS.md` file to track changes to the package.



