This Shiny application demonstrates how to use girafe graphics with modals.

Select a bar on the main graphic by clicking on it and another girafe plot will be 
drawn. If you click one of the legend key, counts will be displayed on the top of the bars.
