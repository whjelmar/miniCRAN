## ---- eval=FALSE--------------------------------------------------------------
#  install.packages("overviewR", force = TRUE)

## ---- message=FALSE, warning=FALSE, results = "hide", eval=FALSE--------------
#  library(devtools)
#  devtools::install_github("cosimameyer/overviewR")

