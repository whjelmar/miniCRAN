## ----eval=FALSE---------------------------------------------------------------
#  library("tinytest")
#  library("checkmate")
#  using("checkmate")

