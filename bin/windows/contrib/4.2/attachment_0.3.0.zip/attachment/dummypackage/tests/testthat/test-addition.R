test_that("Add works", {
  expect_equal(1 + 1, 2)
})
