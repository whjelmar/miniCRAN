# yulab.utils 0.0.5

+ `get_fun_from_pkg()` outputs friendly message if the pkg is not installed (2022-06-08, Wed)
+ `show_in_excel()`, `CRANpkg()`, `Biocpkg()`, `Githubpkg()`, `mypkg()` (2021-10-13, Wed)

# yulab.utils 0.0.4

+ `str_wrap()` (2021-10-09, Sat)

# yulab.utils 0.0.3

+ `read.cb()` (2021-08-17)

# yulab.utils 0.0.2

+ `o()`, `install_zip()`, `get_fun_from_pkg()`

# yulab.utils 0.0.1

+ `is.installed()`, `scihub_dl()`, `sudo_install()`

