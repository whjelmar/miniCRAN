# fable.prophet 0.1.0

* First release.

## New features

* Added interface for the Prophet model (via the 'prophet' R package) to the fable framework.
* Added prophet model methods for: `forecast()`, `components()`, `fitted()`, `residuals()`.
* Added package introduction vignette.
