#ifndef GEOJSONSF_WRITE_GEOJSON_H
#define GEOJSONSF_WRITE_GEOJSON_H

#include <Rcpp.h>

#include "geojsonsf/geojson/writers/write_geojson.hpp"

#endif
