## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = TRUE, eval = FALSE)

## ----echo=FALSE, eval=TRUE, out.width='100%', fig.align='center'--------------
knitr::include_graphics("images/plot-app.png")

