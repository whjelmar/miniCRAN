
Records 1 and 2 are fine
Records 3 and 4 conflict
Record 5 has a missing postal code. Hence we cannot determine whether it conflicts with anything.
