
#### variables

`Rule_17HOUSEHOLDS.csv`:

- hhid: household id
- members: number of members


#### Description of the records

- Record 1: 2 members are found in ```Rule_17PERSONS.csv```
- Record 2: only 2 members are found in `Rule_17PERSONS.csv`
- Record 3: 3 members (1 too many) are found in `Rule_17PERSONS.csv`
- Record 4: 3 members are found in `Rule_17PERSONS.csv`
- Record 5: Undecided since the number of members is unknown.




