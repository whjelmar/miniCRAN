expect_true(
  near(sqrt(2)^2, 2),
  info = "near() accepts nearby fp values"
)
