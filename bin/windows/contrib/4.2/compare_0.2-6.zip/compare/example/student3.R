id <-c(1,2,3,4,5,6)
age <-c(30,32,28,39,20,25)
edu<-c(0,0,0,0,0,0)
class<-c("poor","poor","poor","middle","middle","middle")

IndiaMother<-data.frame(id,age,edu,class)

