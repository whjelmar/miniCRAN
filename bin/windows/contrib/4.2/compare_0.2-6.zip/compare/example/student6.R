> id<-c(1,2,3,4,5,6)
> id
[1] 1 2 3 4 5 6
> age<-c(30,32,28,39,20,25)
> age
[1] 30 32 28 39 20 25
> edu<-c(0,0,0,0,0,0)
> edu
[1] 0 0 0 0 0 0
> class<-c("poor","middle")
> class
[1] "poor"   "middle"
> class1<-rep(class,c(3,3)
+ )
> class1
[1] "poor"   "poor"   "poor"   "middle" "middle" "middle"
> data.frame(id,age,edu,class1)
  id age edu class1
1  1  30   0   poor
2  2  32   0   poor
3  3  28   0   poor
4  4  39   0 middle
5  5  20   0 middle
6  6  25   0 middle

