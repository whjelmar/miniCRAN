# sugarbag 0.1.6

* Changed one print statement to message, at request of CRAN
* Removed dontrun example

# sugarbag 0.1.5

* Update examples to run on win in <5s

# sugarbag 0.1.4

* Update source of data files and documentation to html5

# sugarbag 0.1.3

* Refactor for the dplyr update to version 1.0.2

# sugarbag 0.1.2

* Allow for no focal points to be used

# sugarbag 0.1.1

* Changed uses of nest and unnest due to tidyr changes (#11)

# sugarbag 0.1.0

* First release