## R CMD check results

0 errors | 0 warnings | 1 note

* This is a new release.
