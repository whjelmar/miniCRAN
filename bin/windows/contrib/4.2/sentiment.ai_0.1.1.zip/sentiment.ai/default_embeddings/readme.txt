package will download its default embeddings from github (in json format).

We do this because having a package over ~5Mb is frowned upon, however having them saved will make your runtime much faster!
