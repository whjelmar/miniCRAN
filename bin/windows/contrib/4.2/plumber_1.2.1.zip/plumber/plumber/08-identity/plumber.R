#* @get /name
function(){
	Sys.info()[["nodename"]]
}
