library("ggplot2")

\dontrun{
  show_shapes(calc_shape_pal()(13))
}
