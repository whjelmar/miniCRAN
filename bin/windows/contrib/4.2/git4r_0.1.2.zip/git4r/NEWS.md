# git4r 0.1.0

* Git For R tools checked and used by small user-group

# git4r 0.1.1

* First public release
* Tools streamlined (non-git-related tools culled)
* gitcreds package adopted as optional way of handling credentials

# git4r 0.1.2

* Bug fixes where you must have valid git username before a pull
* Non-bare option removed for a shared-drive remote (git2r::push limitations)
