# ggeasy 0.1.3

* Tests updated to comply with new r-devel all.equal() environment checks
* Added easy_center_title() (#44, @thomas-neitmann)
* New logo (#57, @statnmap)

# ggeasy 0.1.2

* Support for ggplot2 3.3.0 (no implementation change required)
* Added easy_remove_legend_title() (#39, @feddelegrand7)
* Updated covrpage test results
* Repaired failing tests on CRAN

# ggeasy 0.1.1

* Initial CRAN release
* Supports the following shortcuts:

   easy_add_legend_title
   easy_adjust_legend
   easy_all_text_color
   easy_all_text_colour
   easy_all_text_size
   easy_change_legend
   easy_change_text
   easy_labs
   easy_legend_at
   easy_move_legend
   easy_plot_caption_size
   easy_plot_legend_size
   easy_plot_legend_title_size
   easy_plot_subtitle_size
   easy_plot_title_size
   easy_remove_axes
   easy_remove_legend
   easy_remove_x_axis
   easy_remove_y_axis
   easy_rotate_labels
   easy_rotate_legend
   easy_rotate_x_labels
   easy_rotate_y_labels
   easy_text_color
   easy_text_colour
   easy_text_size
   easy_x_axis_labels_size
   easy_x_axis_title_size
   easy_y_axis_labels_size
   easy_y_axis_title_size
