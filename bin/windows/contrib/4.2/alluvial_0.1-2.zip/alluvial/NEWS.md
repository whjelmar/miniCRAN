# alluvial 0.1-2

## New features

- There is a vignette `vignette("alluvial", package="alluvial")` illustrating basic usage of `alluvial()`. The vignette needs `dplyr` package so it is now `Suggested`.

## Minor updates

- README has been updated. It is dynamically generated from an associated `.Rmd` file. Some typos fixed.


# alluvial 0.1-1

First release.