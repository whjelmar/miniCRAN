## ----ex_setup, include=FALSE--------------------------------------------------
knitr::opts_chunk$set(
  message = FALSE,
  digits = 3,
  collapse = TRUE,
  comment = "#>"
  )
options(digits = 3)
library(tidymodels)

## ----tags---------------------------------------------------------------------
library(tidymodels)
tag_show()

