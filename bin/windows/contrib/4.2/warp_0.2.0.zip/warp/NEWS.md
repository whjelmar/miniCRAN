# warp 0.2.0

* All optional arguments must now be specified by name.

* `warp_change()` has two new arguments, `last` and `endpoint`, for controlling
  exactly what type of change points are returned.

# warp 0.1.0

* Added a `NEWS.md` file to track changes to the package.
