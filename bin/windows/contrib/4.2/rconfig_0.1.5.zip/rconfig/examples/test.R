#!/usr/bin/env Rscript
options("rconfig.debug"=TRUE)
str(rconfig::rconfig())
