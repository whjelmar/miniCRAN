# ggpval 0.2.5
* Merge pull request #19, allow pval star and fold change displayed at the same time.
