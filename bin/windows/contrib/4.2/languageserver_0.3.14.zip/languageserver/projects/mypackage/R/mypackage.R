nothing <- function(x, y) {
    NULL
}
