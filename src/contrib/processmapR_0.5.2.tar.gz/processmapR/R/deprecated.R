#' @title Deprecated Functions
#'
#' @description `r lifecycle::badge("deprecated")`
#'
#' [`plotly_dotted_chart()`] has been deprecated in favour of `plotly_dotted_chart(..., plotly = TRUE)`.
#'
#' [`plotly_lined_chart()`] has been deprecated in favour of `plotly_lined_chart(..., plotly = TRUE)`.
#'
#' [`plotly_trace_explorer()`] has been deprecated in favour of `plotly_trace_explorer(..., plotly = TRUE)`.
#'
#' @name deprecated
NULL
#> NULL