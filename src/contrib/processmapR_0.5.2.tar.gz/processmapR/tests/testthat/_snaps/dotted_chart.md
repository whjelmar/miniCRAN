# test dotted_chart on eventlog with param `color`

    Invalid `color`.
    x "employee" is not present in `log`.

