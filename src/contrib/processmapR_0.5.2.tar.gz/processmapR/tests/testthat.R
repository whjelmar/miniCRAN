library(testthat)
library(processmapR)

test_check("processmapR")
