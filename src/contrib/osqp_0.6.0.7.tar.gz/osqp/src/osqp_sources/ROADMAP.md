## TODO
-   [ ] Add GPU solver
-   [ ] Add indirect solver

