library(testthat)
library(osqp)

test_check("osqp")
