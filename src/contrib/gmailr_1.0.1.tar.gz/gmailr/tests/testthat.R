library(testthat)
library(gmailr)

test_check("gmailr")
