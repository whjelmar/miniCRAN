library(testthat)
library(nplyr)

test_check("nplyr")
