/*
 * tomods.h
 *
 * Copyright (c) Chris Putnam 2012-2020
 *
 * Program and source code released under the GPL version 2
 *
 */
#ifndef TOMODS_H
#define TOMODS_H

void tomods_processargs( int *argc, char *argv[], param *p,
        char *help1, char *help2 );


#endif
