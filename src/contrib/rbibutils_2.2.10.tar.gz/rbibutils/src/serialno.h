/*
 * serialno.h
 *
 * Copyright (c) Chris Putnam 2005-2019
 *
 * Source code released under the GPL version 2
 *
 */
#ifndef SERIALNO_H
#define SERIALNO_H

#include "fields.h"

int addsn( fields *info, char *buf, int level );

#endif
