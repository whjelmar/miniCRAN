#' Example event log used in documentation
#'
#' @format An bupaR event log
"example_log"
