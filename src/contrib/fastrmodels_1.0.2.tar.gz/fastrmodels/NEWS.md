# fastrmodels 1.0.2

* Use more efficient compression method for lazy database

# fastrmodels 1.0.1

* Make xgboost an Import to fix a CRAN Package Check Warning.

# fastrmodels 1.0.0

* Initial release.
