# CHANGED IN NNFOR VERSION 0.9.7 (07 JUL 2022)
- Added warning when predict() is called for ELM and MLP. 

# CHANGED IN NNFOR VERSION 0.9.7 (05 JUL 2022)
- Updated dependencies

# CHANGES IN NNFOR VERSION 0.9.6 (15 JAN 2019)
- Updated dependencies

# CHANGES IN NNFOR VERSION 0.9.5 (12 JAN 2019)
- Removed functions mseastest, cmav and lagmatrix from nnfor. These are now available in package tsutils.
- Updated license to GPL-3.

# CHANGES IN NNFOR VERSION 0.9.4 (11 JUL 2018)
- Fix for msts time series and allow.det.season argument.

# CHANGES IN NNFOR VERSION 0.9.3 (01 Apr 2018)
- Changes in how trigonometric seasonal dummies are handled.

# CHANGES IN NNFOR VERSION 0.9.2 (11 Dec 2017)
- Documentation fixes.

# CHANGES IN NNFOR VERSION 0.9.2 (30 Nov 2017)
- Added option to use previously specified mlp and elm (see arguments model and retrain).

# CHANGES IN NNFOR VERSION 0.9.1 (29 Oct 2017)
- Fix on univariate keep vector when no univariate lags are selected (lags=0). 
