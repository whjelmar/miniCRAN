Scoring

This directory contains default embedding -> sentiment models.

Dir structure is: model_type/version

For example, if user passes scoring = 'glm' & version = 1.0 take scoring model from glm/1.0

