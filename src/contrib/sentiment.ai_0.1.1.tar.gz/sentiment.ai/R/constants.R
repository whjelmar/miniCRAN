# 1. EMBEDDINGS/MODELS =========================================================
default_models     <- c(en.large    = "universal-sentence-encoder-large/5",
                        en          = "universal-sentence-encoder/4",
                        multi.large = "universal-sentence-encoder-multilingual-large/3",
                        multi       = "universal-sentence-encoder-multilingual/3")
