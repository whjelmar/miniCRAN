utils::globalVariables(
  names = c(
    "."
  )
)

objects <- new.env()
