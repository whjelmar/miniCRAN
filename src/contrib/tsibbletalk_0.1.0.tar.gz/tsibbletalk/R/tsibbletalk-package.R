#' @keywords internal
#' @import rlang vctrs
"_PACKAGE"
