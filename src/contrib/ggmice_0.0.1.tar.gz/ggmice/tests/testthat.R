library(testthat)
library(ggmice)

test_check("ggmice")
# TODO: check fully complete data
# TODO: check fully complete variable
