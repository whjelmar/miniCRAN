with_example("slides.Rmd", {
    # Render html from Rmd file
    to_html("slides.Rmd")
})
