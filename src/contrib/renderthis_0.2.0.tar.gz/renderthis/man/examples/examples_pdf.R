with_example("slides.Rmd", requires_chrome = TRUE, {
    # Render pdf from Rmd, html, or direct URL
    to_pdf("slides.Rmd")
})
