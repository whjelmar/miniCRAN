with_example("slides.Rmd", requires_chrome = TRUE, {
    # Render gif from Rmd, html, pdf, or direct URL
    to_gif("slides.Rmd")
})
