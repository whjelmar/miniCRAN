with_example("slides.Rmd", requires_chrome = TRUE, requires_packages = "av", {
    # Render mp4 from Rmd, html, pdf, or direct URL
    to_mp4("slides.Rmd")
})
