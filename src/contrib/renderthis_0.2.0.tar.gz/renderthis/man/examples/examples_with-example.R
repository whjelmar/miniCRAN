with_example("slides.Rmd", {
    to_html("slides.Rmd")
})

print(with_example("slides.Rmd", getwd()))
