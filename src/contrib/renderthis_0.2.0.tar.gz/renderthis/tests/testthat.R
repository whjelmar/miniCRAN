library(testthat)
library(renderthis)

test_check("renderthis")
