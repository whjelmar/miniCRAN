Open `examples.Rproj` to open RStudio, then open `examples.R` to run different examples of building slides to different output types.

All output types are built from the main xaringan slide file: `slides.Rmd`
