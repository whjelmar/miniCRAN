double R_angularseparation(double*, int, int, int, int);
double R_chord(double*, int, int, int, int);
double R_geodesic(double*, int, int, int, int);
double R_correlation(double*, int, int, int, int);
void R_distance(double*, int*, int*, double*, int*, int*);
