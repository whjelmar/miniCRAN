Sys.setenv(R_TESTS = "")
library(testthat)
library(ggparliament)

test_check("ggparliament")
