library(testthat)
test_check("Rtsne")