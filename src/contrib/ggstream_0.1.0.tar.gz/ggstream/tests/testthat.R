library(testthat)
library(ggstream)

test_check("ggstream")
