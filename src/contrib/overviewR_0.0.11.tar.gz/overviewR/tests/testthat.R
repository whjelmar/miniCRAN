library(testthat)
library(overviewR)

test_check("overviewR")
