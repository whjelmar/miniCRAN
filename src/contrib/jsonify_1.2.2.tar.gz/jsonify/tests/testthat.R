library(testthat)
library(jsonify)

test_check("jsonify")
