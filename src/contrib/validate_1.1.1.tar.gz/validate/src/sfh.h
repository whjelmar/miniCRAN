/*
 * prototype of Paul Hsieh's SuperFastHash function.
 *
 */
 
#ifndef VALIDATE_SFH_H
#define VALIDATE_SFH_H

uint32_t SuperFastHash (const char * data, int len);

#endif
