
expect_silent(
  as.data.frame(validator(var_group(A, B)>0, C>0))
)

