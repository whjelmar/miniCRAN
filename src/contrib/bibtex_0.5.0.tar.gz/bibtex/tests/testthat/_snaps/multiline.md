# Multiline from file

    @Article{article-full,
      author = {L[eslie] A. Aamport},
      title = {The Gnats and Gnus Document Preparation System.
                Multiline entry},
      journal = {\mbox{G-Animal's} Journal},
      year = {1986},
      volume = {41},
      number = {7},
      pages = {73+},
      month = {jul},
      note = {This is a full ARTICLE entry},
      abstract = {This is a
                  multiline with a concat string},
    }

# Multiline string

    @TechReport{Golub:1976:RDLb,
      author = {G. H. Golub and Virginia Klema and G. W. {Stewart III}},
      title = {Rank Degeneracy and Least Squares Problems},
      type = {Report},
      number = {TR-751},
      institution = {Department of Computer Science,
                                       University of Maryland},
      pages = {????},
      month = {????},
      year = {1976},
      bibdate = {Thu May 29 16:12:45 2014},
      bibsource = {http://www.math.utah.edu/pub/bibnet/authors/g/golub-gene-h.bib;
                     http://www.math.utah.edu/pub/bibnet/authors/s/stewart-gilbert-w.bib},
      acknowledgement = {ack-nhfb},
      gwsnumber = {N6},
      xxnote = {Check: is this the same as Golub:1976:RDLa? If so,
                     which report number is correct??},
    }

