# Preamble from file

    
    Aamport LA (1986). "The Gnats and Gnus Document Preparation System."
    _\mbox{G-Animal's} Journal_.
    
    A BibTeX entry for LaTeX users is
    
      @Article{article-minimal,
        author = {L[eslie] A. Aamport},
        maintainer = {Xavier Albert},
        title = {The Gnats and Gnus Document Preparation System},
        journal = {\mbox{G-Animal's} Journal},
        year = {1986},
      }
    
    
    

# Preamble via params

    @Article{article-full,
      author = {L[eslie] A. Aamport},
      title = {The Gnats and Gnus Document Preparation System},
      journal = {\mbox{G-Animal's} Journal},
      year = {1986},
      volume = {41},
      number = {7},
      pages = {73+},
      month = {jul},
      note = {This is a full ARTICLE entry},
    }

