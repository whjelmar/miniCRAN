# Smith, Jr., John and Mary {Tyler Moore}

    structure(list(list(given = "John", family = c("Smith", "Jr."
    ), role = NULL, email = NULL, comment = NULL), list(given = "Mary", 
        family = "Tyler Moore", role = NULL, email = NULL, comment = NULL)), class = "person")

# Smith, Jr., John and {MATLAB, Inc.}

    structure(list(list(given = "John", family = c("Smith", "Jr."
    ), role = NULL, email = NULL, comment = NULL), list(given = NULL, 
        family = "MATLAB, Inc.", role = NULL, email = NULL, comment = NULL)), class = "person")

# Smith, John Paul and {MATLAB, Inc.}

    structure(list(list(given = c("John", "Paul"), family = "Smith", 
        role = NULL, email = NULL, comment = NULL), list(given = NULL, 
        family = "MATLAB, Inc.", role = NULL, email = NULL, comment = NULL)), class = "person")

# {de Gama}, Vasco

    structure(list(list(given = "Vasco", family = c("de", "Gama"), 
        role = NULL, email = NULL, comment = NULL)), class = "person")

# Mark von Bommel

    structure(list(list(given = "Mark", family = c("von", "Bommel"
    ), role = NULL, email = NULL, comment = NULL)), class = "person")

# de la Soul, Posdnous

    structure(list(list(given = "Posdnous", family = c("de la", "Soul"
    ), role = NULL, email = NULL, comment = NULL)), class = "person")

# des White, Jr., Walter

    structure(list(list(given = "Walter", family = c("des", "White", 
    "Jr."), role = NULL, email = NULL, comment = NULL)), class = "person")

