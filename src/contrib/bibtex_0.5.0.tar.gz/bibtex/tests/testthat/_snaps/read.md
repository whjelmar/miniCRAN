# Test entry with non standard fields

    Van Damme J (2016). "Article title." _Newspaper name_.

---

    @Article{newspaper,
      author = {Jean-Claude {Van Damme}},
      title = {Article title},
      date = {2016-12-21},
      journal = {Newspaper name},
      hyphen-field = {This one},
      under_field = {This one},
      double:field = {This one},
      year = {2016},
    }

