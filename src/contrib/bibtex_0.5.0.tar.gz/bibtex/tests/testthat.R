library(testthat)
library(bibtex)

test_check("bibtex")
