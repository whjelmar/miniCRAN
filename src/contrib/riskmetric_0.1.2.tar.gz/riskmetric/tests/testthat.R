library(testthat)
library(riskmetric)

options(repos = "fake-cran.fake-r-project.org")

test_check("riskmetric")
