# Commenting these out until this is implemented for sourced packages
# test_that("assess_export_help returns expected result for source packages", {
#   expect_true(assess_source_1$export_help[[1]])
#   expect_false(assess_source_2$export_help[[1]])
# })
