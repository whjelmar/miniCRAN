riskmetric.options <- list(
  gitlab_api_host = "https://gitlab.com/api/v4",
  github_api_host = "https://api.github.com"
)
