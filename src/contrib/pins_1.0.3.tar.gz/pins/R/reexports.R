#' @importFrom magrittr %>%
#' @export
magrittr::`%>%`
NULL
