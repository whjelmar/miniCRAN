# can version a local pin

    Version 'doesnt-exist' is not valid, please select from pin_versions().

