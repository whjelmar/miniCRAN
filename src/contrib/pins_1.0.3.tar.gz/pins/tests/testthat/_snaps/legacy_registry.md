# can access entries

    Code
      pin_registry_retrieve(board, "x")
    Condition
      Error in `pin_registry_retrieve()`:
      ! Pin 'x' not found in board 'temp'.

