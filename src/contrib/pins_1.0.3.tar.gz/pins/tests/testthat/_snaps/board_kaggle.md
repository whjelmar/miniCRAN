# can list and search competitions

    Code
      board_deparse(board)
    Output
      [1] "board_kaggle_competitions()"

# can list and search datasets

    Code
      board_deparse(board)
    Output
      [1] "board_kaggle_dataset()"

