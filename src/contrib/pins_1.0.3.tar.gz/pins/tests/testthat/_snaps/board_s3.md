# can deparse

    Code
      board_deparse(board)
    Output
      board_s3(bucket = "pins-test-hadley", region = "us-east-2")

