# can deparse

    Code
      board_deparse(board)
    Output
      board_azure(AzureStor::storage_container("https://pins.file.core.windows.net/test-data"), 
          path = "test/path")

