library(testthat)
library(pins)

test_check("pins")
