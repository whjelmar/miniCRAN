library(rlang)
library(tibble)
library(lubridate)
library(testthat)
library(tsibble)

set.seed(2018)
test_check("tsibble")
