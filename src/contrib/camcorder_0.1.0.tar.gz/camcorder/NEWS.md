# camcorder 0.1.0

* Added a `NEWS.md` file to track changes to the package.
* Most of the functionality of the R package has been developed including:
  - Capturing ggplot2/patchwork plots automatically
  - Capturing other graphic outputs with record_polaroid()
* Preview outputs in the viewer as they are saved
* Generate a GIF of the history of recorded tables
