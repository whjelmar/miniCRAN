#' ifilter functions
#'
#' @name ifilter
NULL
#> NULL