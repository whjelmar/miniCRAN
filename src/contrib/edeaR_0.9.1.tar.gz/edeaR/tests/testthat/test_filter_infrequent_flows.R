
test_that("test filter_infrequent_flows", {
  expect_equal(2 * 2, 4)
})
