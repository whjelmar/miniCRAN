library(testthat)
library(maybe)

test_check("maybe")
