#' @useDynLib rayvertex, .registration = TRUE
#' @importFrom Rcpp evalCpp
NULL
