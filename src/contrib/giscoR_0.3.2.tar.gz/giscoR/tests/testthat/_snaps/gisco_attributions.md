# Testing attributions

    [1] "© EuroGeographics for administrative grænser"

---

    [1] "© EuroGeographics bezuglich der Verwaltungsgrenzen"

---

    [1] "© Eurogeographics para los límites administrativos"

---

    [1] "© EuroGeographics pour les limites administratives"

---

    [1] "© EuroGeographics Association hallinnollisille rajoille"

---

    [1] "© EuroGeographics for administrative grenser"

---

    [1] "© EuroGeographics för administrativa gränser"

---

    [1] "© EuroGeographics for the administrative boundaries"

