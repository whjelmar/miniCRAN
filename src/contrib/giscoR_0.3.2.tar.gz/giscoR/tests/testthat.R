library(testthat)
library(giscoR)

test_check("giscoR")
