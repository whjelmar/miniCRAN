#' @keywords internal
"_PACKAGE"

# import stuffs
#' @importFrom utils download.file unzip read.csv2 menu
NULL
