# print_install_summary [plain]

    Code
      print_install_summary(d)
    Message <cliMessage>
      v 3 deps: kept 1, upd 2, dld 1 (114.69 kB) [12.1s]

---

    Code
      print_install_summary(d)
    Message <cliMessage>
      v 1 pkg + 3 deps: kept 1, upd 2, added 1, dld 1 (114.69 kB) [12.1s]

---

    Code
      print_install_summary(d)
    Message <cliMessage>
      v 4 pkgs: kept 1, upd 2, added 1, dld 1 (114.69 kB) [12.1s]

---

    Code
      print_install_summary(d)
    Message <cliMessage>
      v 4 pkgs: upd 2, added 2, dld 1 (114.69 kB) [12.1s]

---

    Code
      print_install_summary(d)
    Message <cliMessage>
      v 4 pkgs: kept 2, added 2, dld 1 (114.69 kB) [12.1s]

# print_install_summary [fancy]

    Code
      print_install_summary(d)
    Message <cliMessage>
      [32m✔[39m 3 deps: kept 1, upd 2, dld 1 (114.69 kB) [90m[90m[12.1s][90m[39m

---

    Code
      print_install_summary(d)
    Message <cliMessage>
      [32m✔[39m 1 pkg + 3 deps: kept 1, upd 2, added 1, dld 1 (114.69 kB) [90m[90m[12.1s][90m[39m

---

    Code
      print_install_summary(d)
    Message <cliMessage>
      [32m✔[39m 4 pkgs: kept 1, upd 2, added 1, dld 1 (114.69 kB) [90m[90m[12.1s][90m[39m

---

    Code
      print_install_summary(d)
    Message <cliMessage>
      [32m✔[39m 4 pkgs: upd 2, added 2, dld 1 (114.69 kB) [90m[90m[12.1s][90m[39m

---

    Code
      print_install_summary(d)
    Message <cliMessage>
      [32m✔[39m 4 pkgs: kept 2, added 2, dld 1 (114.69 kB) [90m[90m[12.1s][90m[39m

