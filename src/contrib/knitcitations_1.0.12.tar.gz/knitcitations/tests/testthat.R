library("testthat")
library("knitcitations")

test_check("knitcitations")
