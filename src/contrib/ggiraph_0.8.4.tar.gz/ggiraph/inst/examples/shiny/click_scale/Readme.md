Shiny application for interactive legend 

Select a category in the legend by clicking on a key, a summary of the selection is 
rendered.

