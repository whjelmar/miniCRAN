library(testthat)
library(RVenn)

test_check("RVenn")
