library(testthat)
library(nfl4th)

test_check("nfl4th")
