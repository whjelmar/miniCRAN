##' @export
publish.subgroupAnalysis <- function(object,...){
    publish(summary(object,...),...)
}
