##' @export
publish.univariateTable <- function(object,...){
    publish(summary(object,...),...)
}
