library(testthat)
library(messydates)

test_check("messydates")
