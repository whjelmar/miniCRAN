## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  warning = FALSE,
  message = FALSE
)

## ----citation, echo=FALSE, comment = ""---------------------------------------
citation("statsExpressions")

