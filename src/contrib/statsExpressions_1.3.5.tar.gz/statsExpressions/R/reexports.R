# DO NOT REMOVE: Needed for `{ggstatsplot}`

#' @export
#' @importFrom magrittr "%>%"
magrittr::`%>%`

#' @export
#' @importFrom magrittr "%<>%"
magrittr::`%<>%`

#' @export
#' @importFrom magrittr "%$%"
magrittr::`%$%`

#' @export
#' @importFrom zeallot "%<-%"
zeallot::`%<-%`

#' @export
#' @importFrom tibble tibble
tibble::tibble

#' @export
#' @importFrom tibble as_tibble
tibble::as_tibble
