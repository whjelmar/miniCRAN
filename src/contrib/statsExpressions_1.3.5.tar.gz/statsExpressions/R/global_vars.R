# defining global variables and functions to appease R CMD Check

utils::globalVariables(
  names = c(
    ".",
    "effectsize",
    "estimate",
    ".rowid",
    "statistic",
    "std.error",
    "term",
    ".counts",
    "nested_data",
    "df",
    "df.error",
    "k.df",
    "effsize.text",
    "method",
    ".f",
    ".f.es",
    "bf10",
    "conf.low",
    "conf.high",
    "r2.component",
    "conf.level",
    ".fn",
    ".ns",
    "p.value",
    "where",
    "k.df.error",
    "group1",
    "group2",
    "log_e_bf10",
    "p_adjust_text",
    "n.obs"
  ),
  package = "statsExpressions",
  add = FALSE
)
