# Miscellaneous Functions


yarrr.guide <- function() {

  vignette("guide", package = "yarrr")

}
