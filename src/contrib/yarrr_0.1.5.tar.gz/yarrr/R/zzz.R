
.onAttach <- function(libname, pkgname) {
  packageStartupMessage("yarrr v0.1.5. Citation info at citation('yarrr'). Package guide at yarrr.guide()")
  packageStartupMessage("Email me at Nathaniel.D.Phillips.is@gmail.com")
}
