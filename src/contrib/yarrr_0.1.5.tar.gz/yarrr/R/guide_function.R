#'Opens the HTML manual for the yarrr package
#'
#'@keywords misc
#'@export
yarrr.guide <- function(){
  vignette('guide', package = 'yarrr')
}


