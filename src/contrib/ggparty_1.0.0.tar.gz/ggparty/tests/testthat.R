library(testthat)
library(ggparty)

test_check("ggparty")
