Changes
================

### version 1.0.0.

  - finalized DESCRIPTION etc. for CRAN submission

### version 0.0.9003

  - changed add\_vars to require function with correctly named
    arguments.

  - Added GitHub Wiki.

### version 0.0.9002

  - Changed all instances of `aes_string()` to `aes()` with
    quasi-quotations.

### version 0.0.9001

  - Check now runs without any notes.

  - Changed the way parsing works for geom\_edge\_labels. Added vignette
    “On the Edge” outlining this functionality.

  - Many minor fixes.
