trimpartt<-function(x,con){
#
#  This function is used by other functions described in chapter 6.
#
trimpartt<-sum(con*x)
trimpartt
}