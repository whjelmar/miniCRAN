dnormvar<-function(x){
x^2*dnorm(x)
}