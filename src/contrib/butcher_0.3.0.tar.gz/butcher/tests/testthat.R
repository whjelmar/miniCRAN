library(testthat)
library(butcher)

test_check("butcher")
