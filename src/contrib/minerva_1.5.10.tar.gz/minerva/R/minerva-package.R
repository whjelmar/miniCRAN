#' @useDynLib minerva
#' @importFrom Rcpp sourceCpp
#' @importFrom stats na.omit
#' @importFrom stats var
#' @import parallel
NULL