library(testthat)
library(FunnelPlotR)

test_check("FunnelPlotR")
