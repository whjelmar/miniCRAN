# DiagrammeRsvg

A utility package for providing **SVG** export to **DiagrammeR** graph diagrams.

To install the package, use this statement:

```R
devtools::install_github('rich-iannone/DiagrammeRsvg')
```
