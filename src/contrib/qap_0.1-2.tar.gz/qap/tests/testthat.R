library("testthat")

library("qap")
test_check("qap")

