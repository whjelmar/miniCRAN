# qap 0.1-2 (2022-06-27)

* Fixed FORTRAN 2018 issues.

# qap 0.1-1 (2017-02-26)
  
* Fixed reading the optimal solution in read_qaplib.
* Added test.
* Native routines are now registered.

# qap 0.1-0 (2015-10-05)

* Initial release.
