#' @importFrom Rcpp evalCpp
#' @importFrom stats predict
#' @useDynLib word2vec
NULL

