#' @useDynLib skpr, .registration = TRUE
#' @importFrom Rcpp evalCpp
NULL
