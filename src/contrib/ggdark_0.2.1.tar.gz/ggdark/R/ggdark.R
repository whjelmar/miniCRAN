#' 'ggdark': Dark mode for 'ggplot2'
#'
#' Use dark_mode() on your favorite 'ggplot2' theme to activate its dark mode.
#' 'ggdark' also provides dark versions of the themes included in 'ggplot2':
#' dark_theme_grey(), dark_theme_bw(), dark_theme_minimal(), and others.
#' When a dark theme is applied, all geom color and geom fill defaults are inverted
#' to make them visible against a dark background. To change them back, use
#' invert_geom_defaults().
#'
#' @docType package
#' @name ggdark
NULL
