library(testthat)
library(ggdark)

test_check("ggdark")
