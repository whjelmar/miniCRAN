#include "SqliteResultImpl.h"
