# butchered model stack printing works

    Code
      butcher(st_reg_1__)
    Message
      -- A stacked ensemble model -------------------------------------
      
      Print methods for butchered model stacks are disabled.

---

    Code
      butcher(st_class_1__)
    Message
      -- A stacked ensemble model -------------------------------------
      
      Print methods for butchered model stacks are disabled.

---

    Code
      butcher(st_log_1__)
    Message
      -- A stacked ensemble model -------------------------------------
      
      Print methods for butchered model stacks are disabled.

