# fit_members checks for required packages

    The following package needs to be installed before fitting members: `a`

---

    The following packages need to be installed before fitting members: `a` and `b`

---

    The following packages need to be installed before fitting members: `a`, `b`, and `c`

---

    The following packages need to be installed before fitting members: `recipes`, `parsnip`, and `kernlab`

