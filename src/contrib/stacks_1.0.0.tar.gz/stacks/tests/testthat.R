library(testthat)
library(stacks)

test_check("stacks")
