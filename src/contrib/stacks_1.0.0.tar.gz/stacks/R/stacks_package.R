#' stacks: Tidy Model Stacking
#'
#' @docType package
#' @name stacks_description
#' @aliases stacks_package
"_PACKAGE"