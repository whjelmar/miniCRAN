# shinyGizmo 0.2

* Add `conditionalJS` component - extension of `shiny::conditionalPanel` that allows to run custom JS when condition is met.
* Add `valueLink` component.
* Make `showModal` and `hideModal` work with modules.

# shinyGizmo 0.1

* Add `valueButton`, `pickCheckboxInput`, `accordion`, `textArea` and `modalDialogUI` components.
