.onLoad <- function (lib, pkg) {
  options(Matrix.warnDeprecatedCoerce = 2)
}
