library(testthat)
library(fastTopics)
test_check("fastTopics")
