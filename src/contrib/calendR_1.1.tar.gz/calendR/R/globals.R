utils::globalVariables(c("monlabel", "woy", "monthweek", "dow", "y", "fill", "week", "pos.x", "pos.y", "x", "ratio"))
