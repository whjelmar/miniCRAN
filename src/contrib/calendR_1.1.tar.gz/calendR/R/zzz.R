#===================
# On load
#===================
.onAttach <- function(libname, pkgname) {
  packageStartupMessage("~~ Package calendR\nVisit https://r-coder.com/ for R tutorials ~~")
}
