#' gghalves extensions to ggplot2
#' 
#' @name gghalves-extensions
#' @rdname gghalves-extensions
NULL