#' bundle: Serialize Model Objects With A Consistent Interface
#'
#' @docType package
#' @name bundle_description
#' @aliases bundle-package
"_PACKAGE"
