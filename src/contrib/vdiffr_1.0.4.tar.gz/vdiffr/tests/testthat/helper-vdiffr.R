regenerate_snapshots <- function() {
  FALSE
}
