## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----eval = FALSE-------------------------------------------------------------
#  golem::invoke_js("showid", ns("plot"))

## ----eval = FALSE-------------------------------------------------------------
#  golem::invoke_js("showhref", "panel2")

