#' A package for building Shiny App
#'
#' Read more about building big shiny apps at [https://engineering-shiny.org/](https://engineering-shiny.org/).
#'
#' @docType package
#' @name golem
"_PACKAGE"
