library(testthat)
library(bmp)

test_check("bmp")
