library(testthat)
library(shinyauthr)

test_check("shinyauthr")
