------------------------------------------------------------------- 

  Flat Shadow Social Media Icons
  by Lokas Software
  http://www.awicons.com/

------------------------------------------------------------------- 

All icons of this download package are published under the CC Attribution 3.0:
http://creativecommons.org/licenses/by/3.0/

If you want to use these icons  in  your  project, software, 
application or website, you need to maintain an active "DoFollow" link to 
http://www.awicons.com/, with the link text: "Icons by Lokas Software".

If you enjoy these icons please feel free to Twitter, Digg or
recommend the icons on http://www.awicons.com/

For questions, comments, please contact us:
http://www.awicons.com/support/

------------------------------------------------------------------- 

  Custom Design Service

------------------------------------------------------------------- 

Need a custom design? Icons, websites, boxshots, logotypes:
http://www.insoftadesign.com/

