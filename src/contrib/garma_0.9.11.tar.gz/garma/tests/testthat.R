library(testthat)
library(garma)

test_check("garma")
