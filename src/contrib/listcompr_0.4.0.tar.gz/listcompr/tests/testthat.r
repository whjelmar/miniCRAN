library(testthat)
library(listcompr)

test_check("listcompr")
