gridgraphics
============

Redraw base graphics using grid graphics
