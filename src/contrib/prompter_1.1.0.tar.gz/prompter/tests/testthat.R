library(testthat)
library(prompter)

test_check("prompter")
