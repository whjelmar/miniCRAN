test_that("use_prompt doesn't produce anything in workspace or console", {
  expect_silent(use_prompt())
})
