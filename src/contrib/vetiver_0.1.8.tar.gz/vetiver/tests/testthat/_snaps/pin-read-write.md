# can pin a model

    Code
      v
    Output
      
      -- cars1 - <butchered_lm> model for deployment 
      An OLS linear regression model using 2 features

