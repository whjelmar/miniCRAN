# vetiver_pin_metrics(): fails without existing pin

    Can't find pin called 'metrics1'
    ℹ Use `pin_list()` to see all available pins in this board

# vetiver_pin_metrics(): fails with `overwrite = FALSE`

    The new metrics overlap with dates already stored in 'metrics2'
    ℹ Check the aggregated dates or use `overwrite = TRUE`

# vetiver_pin_metrics(): fails with type = csv

    Metrics must be pinned as "arrow" or "rds", not "csv"

---

    Metrics must be pinned as "arrow" or "rds", not "csv"

