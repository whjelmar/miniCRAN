# vetiver_dashboard(): errors without pin

    Code
      vetiver_dashboard(pins = list(board = b, name = "seattle_rf", version = NULL))
    Condition
      Error in `vetiver_dashboard()`:
      ! The pin "seattle_rf" does not exist on your board
      • Check the `pins` params in your dashboard YAML
      ℹ To knit the example vetiver monitoring dashboard, execute `vetiver::pin_example_kc_housing_model()` to set up demo model and metrics pins

