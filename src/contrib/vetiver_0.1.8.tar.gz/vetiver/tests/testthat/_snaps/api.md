# old function is deprecated

    Code
      p <- pr() %>% vetiver_pr_predict(v)
    Condition
      Warning:
      `vetiver_pr_predict()` was deprecated in vetiver 0.1.2.
      Please use `vetiver_api()` instead.

