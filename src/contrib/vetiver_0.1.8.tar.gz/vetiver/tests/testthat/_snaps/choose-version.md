# can warn for strange setups

    Code
      p <- choose_version(p)
    Condition
      Warning:
      Pinned vetiver model has no active version and no datetime on versions
      * Do you need to check your pinned model?
      * Using version 4500

