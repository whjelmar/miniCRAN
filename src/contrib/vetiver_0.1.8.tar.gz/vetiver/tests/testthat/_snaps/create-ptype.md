# bad ptype

    Code
      vetiver_create_ptype(cars_lm, "potato")
    Condition
      Error in `vetiver_create_ptype()`:
      ! The `save_ptype` argument must be TRUE, FALSE, or a dataframe.

