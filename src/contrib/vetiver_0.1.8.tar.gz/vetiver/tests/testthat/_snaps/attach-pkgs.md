# can fail on a single pkg

    Package(s) could not be attached:
    * potato

# can fail on multiple pkgs

    Package(s) could not be attached:
    * potato
    * bloopy

---

    Package(s) could not be attached:
    * potato

