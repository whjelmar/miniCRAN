# missing variables

    The following required columns are missing: 'mpg', 'hp', 'drat', 'wt', 'qsec', 'vs', 'am', 'gear', 'carb'.

# a factor plus a bad character

    [0, 2]: expected value in level set, but got 'ZZ'

# a date

    [0, 1]: expected date like , but got 'potato'

