maxcovar <- function(x, k=1)
{
  
}
