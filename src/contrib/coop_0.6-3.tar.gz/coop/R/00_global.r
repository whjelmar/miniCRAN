### Corresponds to values in src/wrappers.c
CO_SIM <- 1L
CO_ORR <- 2L
CO_VAR <- 3L
