library("testthat")
library("texreg")

test_check("texreg")
