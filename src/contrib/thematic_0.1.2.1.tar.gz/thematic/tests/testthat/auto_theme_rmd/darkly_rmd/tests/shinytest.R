library(shinytest)
shinytest::testApp("../")

