library(testthat)
library(thematic)

test_check("thematic")
