if (requireNamespace("testthat", quietly = TRUE)) {
  library("testthat")
  library("paradox")
  test_check("paradox")
}
