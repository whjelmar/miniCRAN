roxy_files_vignette <- function() {
  paste0(
    "[vignette]",
    "(https://cran.r-project.org/package=filesstrings/vignettes/files.html)."
  )
}
