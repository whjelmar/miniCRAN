library(testthat)
library(terrainr)

test_check("terrainr")
