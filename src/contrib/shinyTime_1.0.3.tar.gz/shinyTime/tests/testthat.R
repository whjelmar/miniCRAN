library(testthat)
library(shinyTime)

test_check("shinyTime")
