library(testthat)
library(slackr)

test_check("slackr")
