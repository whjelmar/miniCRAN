check_suggests <- function() {
  skip_if_not_installed("rvest")
  skip_if_not_installed("xml2")
}
