library(testthat)
library(gtExtras)

test_check("gtExtras")
