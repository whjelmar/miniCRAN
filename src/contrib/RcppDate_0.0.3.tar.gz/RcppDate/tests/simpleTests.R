
## super-simple
## TODO: proper tinytest tests of a compilation or two

stopifnot(system.file("include", "date.h", package="RcppDate") != "")
