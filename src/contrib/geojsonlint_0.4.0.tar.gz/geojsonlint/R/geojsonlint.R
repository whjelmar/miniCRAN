#' Validate GeoJSON using geojsonlint.com web service
#'
#' @export
#' @rdname geojson_lint-defunct
#' @param ... ignored
geojson_lint <- function(...) {
  .Defunct(msg = "the geojsonlint.com web service is gone")
}
