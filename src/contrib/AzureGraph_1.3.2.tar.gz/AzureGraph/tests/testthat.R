library(testthat)
library(AzureGraph)

test_check("AzureGraph")
