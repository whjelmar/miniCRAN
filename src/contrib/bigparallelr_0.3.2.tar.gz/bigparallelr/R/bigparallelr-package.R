#' @keywords internal
#' @import foreach
#' @importFrom bigassertr stop2 assert_pos assert_one_int assert_lengths
"_PACKAGE"
