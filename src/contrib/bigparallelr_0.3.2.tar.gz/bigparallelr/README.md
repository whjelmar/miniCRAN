<!-- badges: start -->
[![R build status](https://github.com/privefl/bigparallelr/workflows/R-CMD-check/badge.svg)](https://github.com/privefl/bigparallelr)
[![AppVeyor build status](https://ci.appveyor.com/api/projects/status/github/privefl/bigparallelr?branch=master&svg=true)](https://ci.appveyor.com/project/privefl/bigparallelr)
[![Coverage status](https://codecov.io/gh/privefl/bigparallelr/branch/master/graph/badge.svg)](https://codecov.io/github/privefl/bigparallelr?branch=master)
<!-- badges: end -->

# bigparallelr

Parallel tools in R
