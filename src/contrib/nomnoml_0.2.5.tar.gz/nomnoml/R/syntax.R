#' Summary of nomnoml syntax.
#'
#' @name nomnoml_syntax
#' @template nomnoml-syntax
#' @rdname nomnoml_syntax
#' @aliases `nomnoml-syntax`
NULL