library(shinytest)
shinytest::testApp("../")
