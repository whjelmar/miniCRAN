library(testthat)
library(nomnoml)

test_check("nomnoml")
