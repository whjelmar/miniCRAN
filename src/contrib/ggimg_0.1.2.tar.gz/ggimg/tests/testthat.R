library(testthat)
library(ggimg)

test_check("ggimg")
