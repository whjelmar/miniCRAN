## -----------------------------------------------------------------------------
print(citation('photobiology'), style = "textVersion")

