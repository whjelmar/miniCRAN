if (requireNamespace("tinytest", quietly=TRUE)) {
	tinytest::test_package("geojsonsf")
}
