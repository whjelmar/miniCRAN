
library(testthat)
library(queuecomputer)

test_check("queuecomputer")
