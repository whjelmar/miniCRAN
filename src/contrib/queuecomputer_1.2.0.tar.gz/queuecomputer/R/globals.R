utils::globalVariables(c("arrivals", "departures", "system_time", "waiting"))
