



release_questions <- function(){
  c(
    "Have you moved the images from the README.Rmd file and edited the README.md file to point to them?"
  )
}
