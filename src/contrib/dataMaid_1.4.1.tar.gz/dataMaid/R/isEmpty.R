#' @title Old version of isSingular, kept for compatibility
#' @rdname isSingular
#' @include isSingular.R
#' @export 
isEmpty <- isSingular 