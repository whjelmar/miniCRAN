library(testthat)
library(dataMaid)

test_check("dataMaid")
