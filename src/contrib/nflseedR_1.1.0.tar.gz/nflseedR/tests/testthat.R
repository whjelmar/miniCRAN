library(testthat)
library(nflseedR)

test_check("nflseedR")
