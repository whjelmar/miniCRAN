context("yesno2")

test_that("question must be a string", {
  expect_error(yesno2())
  expect_error(yesno2(yes = "Really", no = "No way"))
  expect_error(yesno2(yes = 1))
  expect_error(yesno2(yes = character(0)))
  expect_error(yesno2(yes = NA_character_))
  expect_error(yesno2(yes = c("a", "b")))
  expect_error(yesno2(no = 1))
  expect_error(yesno2(no = character(0)))
  expect_error(yesno2(no = NA_character_))
  expect_error(yesno2(no = c("a", "b")))
})
