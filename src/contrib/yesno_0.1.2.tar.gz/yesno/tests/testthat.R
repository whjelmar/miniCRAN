library(testthat)
library(yesno)

test_check("yesno")
