data(logisticTest.df)
BayesLogistic(logisticTest.df$y, logisticTest.df$x, plots = T)

