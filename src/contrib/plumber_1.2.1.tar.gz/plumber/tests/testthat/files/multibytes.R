#* @get /echo
function() {
  "中文消息"
}
