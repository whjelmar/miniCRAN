#* @get /msg
#* @post /msg
function(param1, param2) {
  paste(param1, param2, sep = "-")
}
