#* @get /fail
#* @serializer failingSer
function() {
  "Serialization will fail"
}
