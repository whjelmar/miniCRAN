#* @serializer contentType list(type="text/plain")
#* @get /
function(){
  "RESULT"
}
