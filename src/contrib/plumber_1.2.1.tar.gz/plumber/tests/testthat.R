library(testthat)
library(plumber)

test_check("plumber")
