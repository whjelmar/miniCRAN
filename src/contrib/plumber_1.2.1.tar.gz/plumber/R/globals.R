.globals <- new.env()
.globals$parsers <- list()
.globals$serializers <- list()
.globals$docs <- list()
