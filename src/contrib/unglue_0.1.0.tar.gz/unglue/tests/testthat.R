library(testthat)
library(unglue)

test_check("unglue")
