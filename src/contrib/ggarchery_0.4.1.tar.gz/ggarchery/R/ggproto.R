#' Base ggproto classes for ggarchery
#'
#' @name ggarchery-ggproto
#' @seealso [`ggplot2::ggplot2-ggproto`]
#' @keywords internal
NULL
