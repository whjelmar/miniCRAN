#' @title fauxpas
#' @description HTTP Error Helpers
#' @name fauxpas-package
#' @importFrom R6 R6Class
#' @importFrom httpcode http_code
#' @importFrom whisker whisker.render
#' @aliases fauxpas
#' @docType package
#' @author Scott Chamberlain \email{myrmecocystus@@gmail.com}
#' @keywords package
NULL
