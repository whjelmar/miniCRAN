# circletyper 1.0.2

* Fix test after CRAN notice.

# circletyper 1.0.1

* Remove `LazyData: true` in DESCRIPTION after CRAN notice.

# circletyper 1.0.0

* Added a `NEWS.md` file to track changes to the package.
