# circletype returns the right output

    [1] "<p id=\"test\">this is some text</p><script>var circleTypes = { 'circletypetest': new CircleType(document.getElementById('test')) .dir(-1) .forceWidth(true) .radius(200) }; circleTypes['circletypetest']</script>"

