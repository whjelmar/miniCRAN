test_that("use_circletype shouldn't show anything", {
  expect_silent(use_circletype())
})
