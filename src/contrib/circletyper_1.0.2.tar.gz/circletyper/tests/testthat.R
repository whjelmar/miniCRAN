library(testthat)
library(circletyper)

test_check("circletyper")
