#' Test function
#' @md
#' @section Heading 1:
#'
#' Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod
#' tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
#' quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
#' consequat. Duis aute irure dolor in reprehenderit in voluptate velit
#' esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat
#' cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id
#' est laborum.
#'
#' Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod
#' tempor incididunt ut labore et dolore magna aliqua. Turpis massa tincidunt
#' dui ut ornare lectus. In est ante in nibh. Eu sem integer vitae justo eget.
#' Massa placerat duis ultricies lacus sed turpis. Etiam sit amet nisl purus
#' in mollis nunc sed id. Porta non pulvinar neque laoreet suspendisse interdum
#' consectetur. Risus at ultrices mi tempus imperdiet nulla malesuada
#' pellentesque.
#'
#' ## Heading 2a
#'
#' Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod
#' tempor incididunt ut labore et dolore magna aliqua. Turpis massa tincidunt
#' dui ut ornare lectus. In est ante in nibh. Eu sem integer vitae justo eget.
#' Massa placerat duis ultricies lacus sed turpis. Etiam sit amet nisl purus
#' in mollis nunc sed id. Porta non pulvinar neque laoreet suspendisse interdum
#' consectetur. Risus at ultrices mi tempus imperdiet nulla malesuada
#' pellentesque.
#'
#' Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod
#' tempor incididunt ut labore et dolore magna aliqua. Turpis massa tincidunt
#' dui ut ornare lectus. In est ante in nibh. Eu sem integer vitae justo eget.
#' Massa placerat duis ultricies lacus sed turpis. Etiam sit amet nisl purus
#' in mollis nunc sed id. Porta non pulvinar neque laoreet suspendisse interdum
#' consectetur. Risus at ultrices mi tempus imperdiet nulla malesuada
#' pellentesque.
#'
#' Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod
#' tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
#' quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
#' consequat. Duis aute irure dolor in reprehenderit in voluptate velit
#' esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat
#' cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id
#' est laborum.
#'
#' ## Heading 2b
#'
#' Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod
#' tempor incididunt ut labore et dolore magna aliqua. Turpis massa tincidunt
#' dui ut ornare lectus. In est ante in nibh. Eu sem integer vitae justo eget.
#' Massa placerat duis ultricies lacus sed turpis. Etiam sit amet nisl purus
#' in mollis nunc sed id. Porta non pulvinar neque laoreet suspendisse interdum
#' consectetur. Risus at ultrices mi tempus imperdiet nulla malesuada
#' pellentesque.
#'
#' Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod
#' tempor incididunt ut labore et dolore magna aliqua. Turpis massa tincidunt
#' dui ut ornare lectus. In est ante in nibh. Eu sem integer vitae justo eget.
#' Massa placerat duis ultricies lacus sed turpis. Etiam sit amet nisl purus
#' in mollis nunc sed id. Porta non pulvinar neque laoreet suspendisse interdum
#' consectetur. Risus at ultrices mi tempus imperdiet nulla malesuada
#' pellentesque.
#'
#' Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod
#' tempor incididunt ut labore et dolore magna aliqua. Turpis massa tincidunt
#' dui ut ornare lectus. In est ante in nibh. Eu sem integer vitae justo eget.
#' Massa placerat duis ultricies lacus sed turpis. Etiam sit amet nisl purus
#' in mollis nunc sed id. Porta non pulvinar neque laoreet suspendisse interdum
#' consectetur. Risus at ultrices mi tempus imperdiet nulla malesuada
#' pellentesque.

#' @param x A value
#' @return Nothing
test <- function(x = 1) {

}
