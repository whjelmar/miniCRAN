library(testthat)
library(metrica)
library(dplyr)

test_check("metrica")
