#' @keywords internal
#' @aliases ggmulti-package
"_PACKAGE"

NULL
