

library(testthat)
library(ggmulti)

testthat::test_check("ggmulti")
