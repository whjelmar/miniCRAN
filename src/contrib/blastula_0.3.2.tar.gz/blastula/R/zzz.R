#nocov start

utils::globalVariables(
  c(
    ".",
    "authenticate",
    "email",
    "host",
    "id",
    "key_name",
    "name",
    "port",
    "sender",
    "service",
    "short_name",
    "use_ssl",
    "use_tls",
    "user",
    "username"
    )
  )

#nocov end
