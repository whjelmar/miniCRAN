library(testthat)
library(blastula)

test_check("blastula")
