# redoc 2.0.0.49

- Adds support for Redoc 2.0.0-rc.49


# redoc 2.0.0.45

- Adds support for Redoc 2.0.0-rc.45


# redoc 2.0.0.35

- Adds support for Redoc 2.0.0-rc.35


# redoc 2.0.0.30

- Adds support for Redoc 2.0.0-rc.30
- Adds plumber `mountInterface` integration.

# redoc 2.0.0.29

- Adds support for Redoc 2.0.0-rc.29
