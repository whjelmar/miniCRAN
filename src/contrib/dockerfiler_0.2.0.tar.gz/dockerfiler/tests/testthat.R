library(testthat)
library(dockerfiler)

test_check("dockerfiler")
