#' ggplot extensions
#'
#' @name ggpol-extensions
#' @rdname ggpol-extensions
#' @rdname ggproto-classes
#'
NULL