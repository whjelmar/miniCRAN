# jds.rmd 0.3.1

## Minor updates

* Updated the included `jdsart.cls` from v0.18 to v0.20.


# jds.rmd 0.3.0

## New features

* Provided an additional R markdown template for the latest class file
  `jdsart.cls` developed by VTeX.
* Added function `draft()` following `rmarkdown::draft()` to easily create
  template drafts using `jdsart.cls` or `jds.cls`.


# jds.rmd 0.2.0

## New features

* Provided an R markdown template built upon the internally developed `jds.cls`.
