##' R Markdown Temlates for Journal of Data Science
##'
##' The \pkg{jds.rmd} package provides customized R Markdown templates and
##' formats for authoring and submitting articles to Journal of Data Science
##' (JDS).
##'
##' @docType package
##' @name jds.rmd-package
NULL
