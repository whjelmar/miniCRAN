# diffviewer 0.1.1

* The diffviewer widget previously ignored some very minor pixel differences, 
  but now it will show every difference (#9, #11).

# diffviewer 0.1.0

* Added a `NEWS.md` file to track changes to the package.
