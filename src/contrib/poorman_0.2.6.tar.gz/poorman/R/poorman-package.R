#' @name poorman
#' @docType package
#' @keywords internal
"_PACKAGE"
