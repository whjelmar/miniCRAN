library(testthat)
library(formatters)

test_check("formatters", reporter = "check")
