#' @rdname model_parameters.merMod
#' @export
model_parameters.rlmerMod <- model_parameters.cpglmm


#' @export
p_value.rlmerMod <- p_value.cpglmm
