# classes: .truncreg


#' @export
standard_error.truncreg <- standard_error.default


#' @export
p_value.truncreg <- p_value.default


#' @export
degrees_of_freedom.truncreg <- degrees_of_freedom.mhurdle
