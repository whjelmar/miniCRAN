#' @useDynLib MCMCpack, .registration=TRUE
#' @import coda
#' @import MASS
#' @import stats
#' @import utils
#' @import grDevices
#' @import lattice
#' @import methods
#' @import mcmc
#' @import quantreg
#' @importFrom graphics plot lines abline axTicks axis box layout lcm legend par plot.new plot.window points rect
NULL
#> NULL
