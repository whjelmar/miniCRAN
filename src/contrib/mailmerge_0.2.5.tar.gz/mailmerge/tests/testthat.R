library(testthat)
library(mailmerge)

test_check("mailmerge")
