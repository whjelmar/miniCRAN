library(testthat)
library(parsermd)

test_check("parsermd")
