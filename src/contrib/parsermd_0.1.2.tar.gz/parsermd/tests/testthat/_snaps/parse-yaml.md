# yaml parsing - bad yaml

    Failed to parse line 1
    --
    ^~
    

---

    Failed to parse line 2, expected "---"
    --
    ~~^
    

---

    Failed to parse line 1
    ----
    ~~~^
    

---

    Failed to parse line 2, expected eol
    ----
    ~~~^
    

---

    Failed to parse line 1, expected "---"
    ---
    ~~~^
    

