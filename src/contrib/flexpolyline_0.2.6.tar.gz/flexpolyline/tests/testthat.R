library(testthat)
library(flexpolyline)

test_check("flexpolyline")
