library(testthat)
library(pointblank)
library(dittodb)
test_check("pointblank")
