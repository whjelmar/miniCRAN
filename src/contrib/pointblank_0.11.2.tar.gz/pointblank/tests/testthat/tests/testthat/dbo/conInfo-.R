structure(list(dbname = "master", dbms.name = "Microsoft SQL Server", 
    db.version = "15.00.4053", username = "pointblank", host = "", 
    port = "", sourcename = "", servername = "pacha-laptop", 
    drivername = "libmsodbcsql-17.6.so.1.1", odbc.version = "03.52", 
    driver.version = "17.06.0001", odbcdriver.version = "03.52", 
    supports.transactions = TRUE, getdata.extensions.any_column = FALSE, 
    getdata.extensions.any_order = FALSE), class = c("Microsoft SQL Server", 
"driver_info", "list"))
