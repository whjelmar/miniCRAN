structure(list(DATA_TYPE = c(9L, 9L, 9L, 9L, 9L, 9L, 9L, 9L, 
9L)), class = "data.frame", row.names = c(NA, -9L))
