structure(list(tailnum = "N10156", year = 2004L,
    type = "Fixed wing multi engine", 
    manufacturer = "EMBRAER", model = "EMB-145XR", engines = 2L, 
    seats = 55L, speed = NA_integer_, engine = "Turbo-fan"),
    class = "data.frame", row.names = c(NA, -1L))
