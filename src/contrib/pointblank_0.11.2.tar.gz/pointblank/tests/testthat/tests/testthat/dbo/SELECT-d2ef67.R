structure(list(n = 3322L), class = "data.frame", row.names = c(NA, 
-1L))
