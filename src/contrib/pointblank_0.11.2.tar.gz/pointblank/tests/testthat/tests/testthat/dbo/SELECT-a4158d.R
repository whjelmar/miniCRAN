structure(list(n = 3252L), class = "data.frame", row.names = c(NA, 
-1L))
