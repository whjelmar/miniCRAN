structure(list(tailnum = character(0), year = integer(0), type = character(0), 
    manufacturer = character(0), model = character(0), engines = integer(0), 
    seats = integer(0), speed = integer(0), engine = character(0)),
    class = "data.frame", row.names = c(NA, 0L))
