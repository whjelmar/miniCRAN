structure(list(n = 0L), class = "data.frame", row.names = c(NA, 
-1L))
