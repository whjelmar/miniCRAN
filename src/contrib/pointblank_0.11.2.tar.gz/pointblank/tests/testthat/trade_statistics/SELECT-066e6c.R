structure(list(year = integer(0), reporter_iso = character(0), 
    partner_iso = character(0), export_value_usd = numeric(0), 
    import_value_usd = numeric(0)), class = "data.frame", row.names = c(NA, 
0L))
