list(dbname = "trade_statistics", host = "tradestatistics.io", 
    port = "5432", user = "guest", protocol_version = 3L,
    server_version = 101200L, pid = 12352L)
