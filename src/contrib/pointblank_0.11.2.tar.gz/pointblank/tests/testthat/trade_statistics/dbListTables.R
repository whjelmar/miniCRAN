c("attributes_sections_names", "attributes_sections_colors", 
"attributes_countries", "attributes_products_shortnames", "hs07_yr", 
"hs07_yrp", "hs07_yrpc", "attributes_groups", "hs07_yrc", "attributes_sections",
"attributes_sections_shortnames", "hs07_yc", "attributes_products_names"
)
