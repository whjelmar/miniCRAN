structure(list(n = structure(0x0p+0, class = "integer64")),
          class = "data.frame", row.names = c(NA, -1L))
