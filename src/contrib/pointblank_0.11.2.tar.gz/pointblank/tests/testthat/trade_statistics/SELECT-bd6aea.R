structure(list(n = structure(0x1.40c1ap-1054, class = "integer64")), class = "data.frame", row.names = c(NA, 
-1L))
