structure(list(year = 2018L, reporter_iso = "afg", partner_iso = "ago", 
    export_value_usd = 0x1.772bp+16, import_value_usd = 0x1.466cp+14),
    class = "data.frame", row.names = c(NA, -1L))
