structure(list(column_name = c("year", "reporter_iso", "partner_iso", 
"export_value_usd", "import_value_usd"), data_type = c("integer", 
"character varying", "character varying", "numeric", "numeric"
)), class = "data.frame", row.names = c(NA, -5L))
