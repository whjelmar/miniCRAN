structure(list(DATA_TYPE = c("int", "int", "int", "int", "int", 
"int", "tinyint")), class = "data.frame", row.names = c(NA, -7L
))
