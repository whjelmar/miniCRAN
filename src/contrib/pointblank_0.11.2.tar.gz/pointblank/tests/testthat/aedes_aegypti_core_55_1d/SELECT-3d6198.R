structure(list(asm_seq_region_id = integer(0), cmp_seq_region_id = integer(0), 
    asm_start = integer(0), asm_end = integer(0), cmp_start = integer(0), 
    cmp_end = integer(0), ori = integer(0)), class = "data.frame",
    row.names = c(NA, 0L))
