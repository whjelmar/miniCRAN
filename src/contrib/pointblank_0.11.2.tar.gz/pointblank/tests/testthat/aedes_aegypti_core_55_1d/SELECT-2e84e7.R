structure(list(asm_seq_region_id = 1L, cmp_seq_region_id = 39968L, 
    asm_start = 1L, asm_end = 5950L, cmp_start = 1L, cmp_end = 5950L, 
    ori = 1L), class = "data.frame", row.names = c(NA, -1L))
