structure(list(n = structure(0x0.0000000008d6dp-1022, class = "integer64")),
          class = "data.frame", row.names = c(NA, -1L))
