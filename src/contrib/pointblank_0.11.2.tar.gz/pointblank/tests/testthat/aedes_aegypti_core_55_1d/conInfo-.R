list(host = "ensembldb.ensembl.org", username = "anonymous", 
    dbname = "aedes_aegypti_core_55_1d",
    con.type = "ensembldb.ensembl.org via TCP/IP", 
    db.version = "5.6.33", port = NA_integer_, protocol.version = 10L, 
    thread.id = 3323792L)
