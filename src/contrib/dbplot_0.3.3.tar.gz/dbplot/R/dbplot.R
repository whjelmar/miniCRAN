#' @import rlang
#' @import ggplot2
#' @importFrom purrr imap
#' @importFrom dplyr mutate summarise
#' @importFrom dplyr group_by count pull
#' @importFrom dplyr ungroup collect rename
#' @importFrom dplyr select n tibble distinct
#' @importFrom stats quantile
#' @keywords internal
utils::globalVariables(c("."))
