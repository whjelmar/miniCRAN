library(testthat)
library(cranlogs)

test_check("cranlogs")
