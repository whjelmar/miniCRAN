library(testthat)
library(unifir)
Sys.setenv("unifir_debugmode" = "true")
test_check("unifir")
