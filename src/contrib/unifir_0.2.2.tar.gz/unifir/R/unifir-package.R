#' @keywords internal
"_PACKAGE"

# Theoretically this should suppress a NOTE in R CMD CHECK
#' @importFrom R6 R6Class

## usethis namespace: start
## usethis namespace: end
NULL
