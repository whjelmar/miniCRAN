library(testthat)
library(sdcMicro)

test_check("sdcMicro")
