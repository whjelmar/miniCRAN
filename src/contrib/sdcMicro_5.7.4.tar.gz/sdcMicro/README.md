sdcMicro
========

[![R-CMD-check](https://github.com/sdcTools/sdcMicro/actions/workflows/R-CMD-check.yaml/badge.svg)](https://github.com/sdcTools/sdcMicro/actions/workflows/R-CMD-check.yaml)
[![CRAN](http://www.r-pkg.org/badges/version/sdcMicro)](https://CRAN.R-project.org/package=sdcMicro)
[![Downloads](http://cranlogs.r-pkg.org/badges/sdcMicro)](https://CRAN.R-project.org/package=sdcMicro)
[![Mentioned in Awesome Official Statistics ](https://awesome.re/mentioned-badge.svg)](https://github.com/SNStatComp/awesome-official-statistics-software)


**sdcMicro** is an R-package to anonymize microdata. Most functionalities of the package are also available via an interactive shiny-based graphical user interface.

The online documentation can also be found at [`sdctools.github.io/sdcMicro`](https://sdctools.github.io/sdcMicro/index.html).
