library(testthat)
library(ggformula)

test_check("ggformula")
