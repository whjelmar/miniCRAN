### News

waffle 0.7.0
- yet more fixes for latest ggplot2 2.x
- made factor-level keeping a parameter (TRUE by default)

waffle 0.6.0
- keep factor levels; improve default aesthetics

waffle 0.5.1
- even moar improved ggplot2 compatibility

waffle 0.5
- new & improved ggplot2 compatibility

waffle 0.4
- added `use_glyph()` and `glyph_size()` to `waffle()` so you can now make isotype pictograms

waffle 0.3
- added a `pad parameter to `waffle to make it easier to align plots
- added `iron to make it easier to do the alignment

waffle 0.2.3
- nulled many margins and made the use of `coord_equal optional via the `equal parameter

waffle 0.2.1
- added Travis tests to ensure independent package build confirmation

waffle 0.2
- added `as_rcdimple thx to Kent Russell (only in non-CRAN version)

waffle 0.1
- initial release
