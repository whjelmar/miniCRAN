library(testthat)
library(CVXR)

test_check("CVXR", filter="^g01")
