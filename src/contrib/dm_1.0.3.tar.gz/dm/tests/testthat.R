library(testthat)

# Need to use qualified call, this is checked in helper-print.R
testthat::test_check("dm")
