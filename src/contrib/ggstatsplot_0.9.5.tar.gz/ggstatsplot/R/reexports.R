#' @export
#' @importFrom statsExpressions "%>%"
statsExpressions::`%>%`

#' @export
#' @importFrom statsExpressions pairwise_comparisons
statsExpressions::pairwise_comparisons
