# grouped_ggbarstats produces error when grouping variable not provided

    argument 1 is empty

