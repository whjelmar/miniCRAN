# checking if extract_stats works

    Code
      length(extract_stats(p1))
    Output
      [1] 7

---

    Code
      length(extract_stats(p2))
    Output
      [1] 7

---

    Code
      length(extract_stats(p3))
    Output
      [1] 7

---

    Code
      length(extract_stats(p4)$pairwise_comparisons_data)
    Output
      [1] 9

---

    Code
      length(extract_stats(p5))
    Output
      [1] 7

---

    Code
      length(extract_stats(p6))
    Output
      [1] 7

---

    Code
      length(extract_stats(p7))
    Output
      [1] 7

