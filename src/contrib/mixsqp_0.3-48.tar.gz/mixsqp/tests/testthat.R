library(testthat)
library(mixsqp)
test_check("mixsqp")
