# readbitmap 0.1.5

* Added a `NEWS.md` file to track changes to the package.
* Support for reading TIFF images thanks to Derek Ogle (#4)
* read.bitmap now reads ARGB bmp images into RGBA array (#5)
  thanks to Simon Bartheleme (@dahtah).
