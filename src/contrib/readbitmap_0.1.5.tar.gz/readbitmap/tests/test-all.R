library(testthat)
library(readbitmap)

test_check("readbitmap")
