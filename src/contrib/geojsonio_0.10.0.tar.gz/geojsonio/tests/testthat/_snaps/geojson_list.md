# geojson_list works with data.frame inputs

    {
      "type": "list",
      "attributes": {
        "names": {
          "type": "character",
          "attributes": {},
          "value": ["type", "features"]
        },
        "from": {
          "type": "character",
          "attributes": {},
          "value": ["data.frame"]
        }
      },
      "value": [
        {
          "type": "character",
          "attributes": {},
          "value": ["FeatureCollection"]
        },
        {
          "type": "list",
          "attributes": {},
          "value": [
            {
              "type": "list",
              "attributes": {
                "names": {
                  "type": "character",
                  "attributes": {},
                  "value": ["type", "geometry", "properties"]
                }
              },
              "value": [
                {
                  "type": "character",
                  "attributes": {},
                  "value": ["Feature"]
                },
                {
                  "type": "list",
                  "attributes": {
                    "names": {
                      "type": "character",
                      "attributes": {},
                      "value": ["type", "coordinates"]
                    }
                  },
                  "value": [
                    {
                      "type": "character",
                      "attributes": {},
                      "value": ["Polygon"]
                    },
                    {
                      "type": "list",
                      "attributes": {},
                      "value": [
                        {
                          "type": "list",
                          "attributes": {},
                          "value": [
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-87.46201, 30.38968]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-87.48493, 30.37249]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-87.52503, 30.37249]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-87.53076, 30.33239]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-87.57087, 30.32665]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-87.58806, 30.32665]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-87.59379, 30.30947]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-87.59379, 30.28655]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-87.674, 30.27509]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-87.81152, 30.2579]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-87.88026, 30.24644]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-87.92037, 30.24644]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-87.95475, 30.24644]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-88.00632, 30.24071]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-88.01778, 30.25217]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-88.01205, 30.26936]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-87.99486, 30.27509]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-87.95475, 30.27509]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-87.90318, 30.28082]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-87.8287, 30.28655]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-87.80006, 30.28655]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-87.80006, 30.32665]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-87.81724, 30.34385]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-87.84016, 30.38395]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-87.85162, 30.40114]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-87.87453, 30.4126]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-87.90318, 30.42406]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-87.9261, 30.44698]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-87.93183, 30.49281]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-87.94329, 30.52719]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-87.92037, 30.56157]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-87.91464, 30.58449]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-87.9261, 30.61886]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-87.92037, 30.67043]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-87.94902, 30.69908]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-87.98913, 30.79075]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-88.00632, 30.79648]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-88.01778, 30.80221]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-88.03497, 30.79075]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-88.04642, 30.75638]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-88.05215, 30.72773]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-88.05215, 30.71054]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-88.06361, 30.68762]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-88.06934, 30.68189]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-88.0808, 30.63033]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-88.0808, 30.61314]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-88.09799, 30.60741]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-88.10944, 30.59595]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-88.11518, 30.58449]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-88.10944, 30.55584]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-88.12091, 30.48136]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-88.12091, 30.44125]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-88.12664, 30.38968]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-88.13237, 30.36103]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-88.14383, 30.34385]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-88.16102, 30.33812]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-88.17248, 30.33812]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-88.18966, 30.3553]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-88.22404, 30.37822]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-88.2355, 30.39541]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-88.28706, 30.40114]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-88.31571, 30.40114]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-88.3329, 30.40114]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-88.3501, 30.42406]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-88.39021, 30.4126]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-88.40739, 30.73346]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-88.41885, 30.99702]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-88.43031, 31.12307]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-88.45322, 31.43247]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-88.46468, 31.69603]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-88.47614, 31.89083]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-88.43031, 32.22314]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-88.43031, 32.30909]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-88.39021, 32.57838]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-88.3501, 32.92215]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-88.33863, 32.98518]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-88.29853, 33.28312]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-88.2756, 33.52949]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-88.25269, 33.73576]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-88.20686, 34.06234]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-88.20686, 34.07953]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-88.18394, 34.31444]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-88.16675, 34.46341]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-88.14955, 34.58373]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-88.10944, 34.89886]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-88.13237, 34.90459]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-88.16675, 34.95043]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-88.18966, 34.99627]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-88.18394, 35.01345]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-87.98913, 35.01345]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-87.60525, 35.00772]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-87.2271, 35.00199]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-87.20417, 35.00199]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-86.82603, 34.99627]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-86.78019, 34.99053]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-86.31036, 34.99053]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-85.852, 34.9848]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-85.61135, 34.97907]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-85.58844, 34.84156]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-85.5426, 34.61811]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-85.52541, 34.58373]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-85.46812, 34.26287]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-85.42801, 34.07953]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-85.40509, 33.95921]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-85.39363, 33.90764]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-85.34779, 33.66127]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-85.31342, 33.49511]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-85.29623, 33.43209]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-85.24466, 33.11696]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-85.23893, 33.1055]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-85.19309, 32.87059]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-85.19309, 32.85913]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-85.17018, 32.84194]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-85.14725, 32.79037]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-85.13007, 32.76746]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-85.13007, 32.75027]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-85.12434, 32.73308]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-85.10142, 32.67578]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-85.10142, 32.63567]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-85.06704, 32.60703]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-85.04986, 32.55546]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-85.00975, 32.52682]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-84.98683, 32.49817]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-84.99256, 32.46952]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-84.97537, 32.42368]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-84.98109, 32.37785]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-85.00402, 32.33774]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-84.97537, 32.30909]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-84.92381, 32.28044]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-84.90089, 32.25179]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-84.92953, 32.23461]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-84.95245, 32.22887]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-84.96964, 32.20023]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-84.99256, 32.18304]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-85.04986, 32.16012]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-85.06131, 32.12001]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-85.06131, 32.10283]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-85.06131, 32.08564]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-85.06131, 32.06272]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-85.06131, 32.02834]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-85.06131, 31.99396]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-85.07851, 31.95959]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-85.10715, 31.93667]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-85.14153, 31.86791]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-85.1358, 31.7877]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-85.1358, 31.77624]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-85.13007, 31.7304]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-85.11861, 31.68456]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-85.07851, 31.61581]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-85.06131, 31.55852]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-85.06131, 31.52414]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-85.08424, 31.4783]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-85.08424, 31.44392]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-85.0957, 31.40955]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-85.0957, 31.34079]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-85.10142, 31.30068]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-85.12434, 31.28349]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-85.12434, 31.25485]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-85.11288, 31.19182]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-85.11288, 31.17463]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-85.08997, 31.14026]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-85.04413, 31.11161]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-85.0384, 31.09442]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-85.03267, 31.07723]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-85.03267, 31.03712]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-85.01548, 31.00275]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-85.01548, 30.99702]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-85.49677, 31.00847]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-85.51968, 31.00847]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-86.0468, 31.00847]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-86.2015, 31.00847]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-86.39057, 31.00847]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-86.7057, 31.00847]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-86.79737, 31.00847]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-87.18126, 31.00847]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-87.60525, 31.00847]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-87.60525, 30.95691]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-87.61097, 30.93399]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-87.6339, 30.89962]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-87.63963, 30.8767]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-87.6339, 30.85951]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-87.61097, 30.84232]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-87.54795, 30.77356]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-87.49065, 30.722]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-87.46201, 30.71054]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-87.45055, 30.69908]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-87.4219, 30.67616]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-87.41044, 30.64751]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-87.41044, 30.61886]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-87.43336, 30.58449]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-87.46201, 30.54438]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-87.46774, 30.52719]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-87.46201, 30.51]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-87.44482, 30.49281]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-87.39899, 30.45844]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-87.39326, 30.44698]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-87.40472, 30.42979]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-87.4219, 30.42979]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-87.43909, 30.42406]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-87.43909, 30.41833]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-87.45055, 30.40114]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-87.46201, 30.38968]
                            }
                          ]
                        }
                      ]
                    }
                  ]
                },
                {
                  "type": "list",
                  "attributes": {
                    "names": {
                      "type": "character",
                      "attributes": {},
                      "value": ["group", "order", "region", "subregion"]
                    }
                  },
                  "value": [
                    {
                      "type": "character",
                      "attributes": {},
                      "value": ["1"]
                    },
                    {
                      "type": "character",
                      "attributes": {},
                      "value": ["  1"]
                    },
                    {
                      "type": "character",
                      "attributes": {},
                      "value": ["alabama"]
                    },
                    {
                      "type": "character",
                      "attributes": {},
                      "value": [null]
                    }
                  ]
                }
              ]
            },
            {
              "type": "list",
              "attributes": {
                "names": {
                  "type": "character",
                  "attributes": {},
                  "value": ["type", "geometry", "properties"]
                }
              },
              "value": [
                {
                  "type": "character",
                  "attributes": {},
                  "value": ["Feature"]
                },
                {
                  "type": "list",
                  "attributes": {
                    "names": {
                      "type": "character",
                      "attributes": {},
                      "value": ["type", "coordinates"]
                    }
                  },
                  "value": [
                    {
                      "type": "character",
                      "attributes": {},
                      "value": ["Polygon"]
                    },
                    {
                      "type": "list",
                      "attributes": {},
                      "value": [
                        {
                          "type": "list",
                          "attributes": {},
                          "value": [
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-114.63739, 35.01918]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-114.64313, 35.10512]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-114.60302, 35.12231]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-114.57436, 35.17961]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-114.58583, 35.2369]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-114.59728, 35.28274]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-114.60874, 35.35723]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-114.62594, 35.40879]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-114.66605, 35.45463]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-114.66031, 35.50047]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-114.66605, 35.54057]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-114.67178, 35.60933]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-114.68324, 35.66662]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-114.70042, 35.71246]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-114.70042, 35.79268]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-114.68896, 35.88435]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-114.71188, 35.91299]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-114.7348, 35.95883]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-114.7348, 36.01613]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-114.75771, 36.06197]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-114.7348, 36.1078]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-114.70042, 36.11926]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-114.64313, 36.14218]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-114.55718, 36.15364]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-114.48843, 36.13645]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-114.39675, 36.13645]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-114.328, 36.11353]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-114.31081, 36.04478]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-114.26498, 36.02758]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-114.20194, 36.02186]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-114.13892, 36.03905]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-114.116, 36.09634]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-114.08163, 36.13645]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-114.05298, 36.21093]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-114.04725, 36.84119]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-114.04152, 36.99588]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-113.8238, 36.99588]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-113.53732, 37.00161]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-113.27949, 37.00161]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-113.00447, 37.00161]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-112.90707, 36.99588]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-112.72945, 37.00161]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-112.54037, 36.99588]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-112.41432, 36.99588]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-112.20805, 36.99588]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-111.95023, 37.00161]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-111.68667, 37.00161]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-111.41164, 37.00161]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-111.31997, 37.00161]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-111.25121, 36.99588]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-111.12516, 36.99588]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-110.84441, 37.00161]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-110.75847, 36.99588]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-110.68399, 36.99588]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-110.54648, 36.99588]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-110.30583, 37.00161]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-110.0881, 37.00161]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-110.0079, 37.00161]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-109.93341, 36.99588]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-109.71568, 36.99588]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-109.41203, 36.99588]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-109.14846, 36.99588]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-109.0396, 36.99588]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-109.04533, 35.99894]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-109.05106, 34.95043]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-109.05106, 34.57227]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-109.05679, 33.77586]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-109.05106, 33.2029]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-109.05679, 32.77892]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-109.05679, 32.42368]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-109.05679, 31.35225]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-109.23441, 31.35225]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-109.62402, 31.34652]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-109.99644, 31.35225]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-110.35167, 31.35225]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-110.47772, 31.35225]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-110.63242, 31.35225]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-110.98766, 31.34652]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-111.11943, 31.35798]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-111.29705, 31.41528]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-111.38873, 31.44392]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-111.62936, 31.51841]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-112.03616, 31.65019]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-112.32838, 31.74186]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-112.66642, 31.83927]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-112.92998, 31.92521]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-113.18781, 32.00542]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-113.34824, 32.05699]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-113.46856, 32.0971]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-113.74358, 32.18877]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-114.0358, 32.27471]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-114.31654, 32.36066]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-114.70042, 32.48098]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-114.80928, 32.51535]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-114.79781, 32.57838]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-114.76917, 32.67006]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-114.7348, 32.73308]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-114.68896, 32.74454]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-114.65459, 32.73881]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-114.59156, 32.73881]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-114.55145, 32.76173]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-114.5228, 32.82475]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-114.47697, 32.87632]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-114.47697, 32.93362]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-114.4827, 32.99664]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-114.53999, 33.04247]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-114.66031, 33.05394]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-114.70042, 33.08258]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-114.71188, 33.13415]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-114.68896, 33.26593]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-114.74052, 33.31176]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-114.71761, 33.3576]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-114.72906, 33.40344]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-114.68896, 33.43209]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-114.64885, 33.45501]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-114.63739, 33.48365]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-114.60874, 33.50084]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-114.6202, 33.52949]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-114.56864, 33.54668]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-114.55718, 33.57533]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-114.52853, 33.63262]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-114.53999, 33.69565]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-114.5228, 33.73003]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-114.53999, 33.78159]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-114.53999, 33.92483]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-114.51707, 33.96494]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-114.45405, 33.99932]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-114.47124, 34.0165]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-114.44832, 34.03942]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-114.41967, 34.07953]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-114.39675, 34.11391]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-114.29935, 34.15401]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-114.2306, 34.19985]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-114.19049, 34.24569]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-114.13319, 34.26287]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-114.13892, 34.29725]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-114.16756, 34.33736]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-114.28789, 34.4233]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-114.37383, 34.46914]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-114.40249, 34.58946]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-114.41967, 34.61238]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-114.44832, 34.70978]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-114.57436, 34.80719]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-114.55145, 34.83583]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-114.54572, 34.84729]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-114.56864, 34.86448]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-114.60874, 34.8874]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-114.63167, 34.96188]
                            },
                            {
                              "type": "double",
                              "attributes": {},
                              "value": [-114.63739, 35.01918]
                            }
                          ]
                        }
                      ]
                    }
                  ]
                },
                {
                  "type": "list",
                  "attributes": {
                    "names": {
                      "type": "character",
                      "attributes": {},
                      "value": ["group", "order", "region", "subregion"]
                    }
                  },
                  "value": [
                    {
                      "type": "character",
                      "attributes": {},
                      "value": ["2"]
                    },
                    {
                      "type": "character",
                      "attributes": {},
                      "value": ["204"]
                    },
                    {
                      "type": "character",
                      "attributes": {},
                      "value": ["arizona"]
                    },
                    {
                      "type": "character",
                      "attributes": {},
                      "value": [null]
                    }
                  ]
                }
              ]
            }
          ]
        }
      ]
    }

