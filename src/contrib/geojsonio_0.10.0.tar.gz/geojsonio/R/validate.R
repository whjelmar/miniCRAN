#' Validate a geoJSON file, json object, list, or Spatial class.
#'
#' @export
#' @name validate-defunct
#' @keywords internal
#' @param ... ignored
validate <- function(...) .Defunct("geojsonlint::geojson_lint()")
