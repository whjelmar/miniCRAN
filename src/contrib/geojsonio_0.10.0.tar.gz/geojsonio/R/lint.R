#' Lint geojson
#'
#' @export
#' @name lint-defunct
#' @keywords internal
#' @param ... ignored
lint <- function(...) .Deprecated("geojsonlint::geojson_hint")
