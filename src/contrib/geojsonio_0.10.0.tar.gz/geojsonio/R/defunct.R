#' Defunct functions in geojsonio
#'
#' - [lint()]: See `geojsonlint::geojson_hint`
#' - [validate()]: See `geojsonlint::geojson_lint`
#'
#' @name geojsonio-defunct
NULL