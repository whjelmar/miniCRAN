library(testthat)
library(roll)

test_check("roll")