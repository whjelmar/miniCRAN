dot_size <- function(n){
  (1 / exp(0.005 * (n - 1))) * 3
}
