#' @importFrom utils object.size
format_size <- function(size) format(size, standard = "auto", unit = "auto", digits = 2L)