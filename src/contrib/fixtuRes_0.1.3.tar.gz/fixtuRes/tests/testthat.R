library(testthat)
library(fixtuRes)

testthat::test_check("fixtuRes")
