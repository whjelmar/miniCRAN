library(testthat)
local_edition(3)

library(vmr)

test_check("vmr")
