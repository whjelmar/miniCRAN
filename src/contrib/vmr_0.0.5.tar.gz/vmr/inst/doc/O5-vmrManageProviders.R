## ----eval=FALSE---------------------------------------------------------------
#  vb.opt <- virtualboxOptions(details = FALSE)

## ----eval=FALSE---------------------------------------------------------------
#  vb.opt$name <- "My Virtualbox name"

## ----eval=FALSE---------------------------------------------------------------
#  vb.opt$gui <- FALSE

## ----eval=FALSE---------------------------------------------------------------
#  vb.opt$modifyvm$cpus <- 3
#  vb.opt$modifyvm$memory <- 8192

