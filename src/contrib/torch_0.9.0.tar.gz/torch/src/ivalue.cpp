#include <torch.h>

// [[Rcpp::export]]
XPtrTorchIValue ivalue_test_function(XPtrTorchIValue x) { return x; }
