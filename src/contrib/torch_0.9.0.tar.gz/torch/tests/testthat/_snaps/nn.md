# print method works

    An `nn_module` containing 221 parameters.
    
    ── Modules ───────────────────────────────────────
    • linear: <nn_linear> #110 parameters
    • linear2: <nn_linear> #11 parameters
    
    ── Parameters ────────────────────────────────────
    • x: Float [1:10, 1:10]
    
    ── Buffers ───────────────────────────────────────
    • k: Float [1:5, 1:5]

