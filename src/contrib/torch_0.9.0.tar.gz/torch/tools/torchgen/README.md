
# torchgen

<!-- badges: start -->
<!-- badges: end -->

`torchgen` is used to autogenerate most wrapers for the torch package.

## Example

```
torchgen::generate("path/to/root/torch/package")
```
