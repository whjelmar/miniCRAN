library(testthat)
library(nflreadr)

test_check("nflreadr")
