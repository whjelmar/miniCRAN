library(testthat)
library(shinyMobile)

test_check("shinyMobile")
