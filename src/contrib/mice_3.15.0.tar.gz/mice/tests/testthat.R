library(testthat)
library(mice)

test_check("mice")
