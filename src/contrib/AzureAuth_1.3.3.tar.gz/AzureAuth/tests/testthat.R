library(testthat)
library(AzureAuth)

test_check("AzureAuth")
