library(testthat)
library(ggVennDiagram)

test_check("ggVennDiagram")
