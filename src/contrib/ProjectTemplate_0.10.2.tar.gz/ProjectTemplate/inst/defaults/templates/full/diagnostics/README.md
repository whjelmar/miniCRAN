Here you can store any scripts you use to diagnose your data sets for corruption or problematic data points.
