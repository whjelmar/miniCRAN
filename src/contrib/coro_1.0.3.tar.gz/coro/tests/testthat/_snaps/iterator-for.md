# loop() fails informatively inside generators (#31)

    Can't use `loop()` within a generator.
    i `for` loops already support iterators in generator functions.

