library(testthat)
library(coro)

test_check("coro")
