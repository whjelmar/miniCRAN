makepipe::make_register(5, 'five')
