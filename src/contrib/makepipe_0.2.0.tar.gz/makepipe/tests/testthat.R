library(testthat)
library(makepipe)

test_check("makepipe")
