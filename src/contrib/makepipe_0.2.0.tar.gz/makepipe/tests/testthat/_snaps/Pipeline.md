# cleaning triggers rebuild

    Code
      pipe$build()
    Message <cliMessage>
      i Targets are out of date. Updating...
    Output
      
    Message <cliMessage>
      v Finished updating
      
      i Targets are out of date. Updating...
    Output
      
    Message <cliMessage>
      v Finished updating
      

