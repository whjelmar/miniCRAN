# Figure colour scheme

Light pink - #f4c8f1
Dark pink - #c3a0c0
Light blue - #f4c8f1
Light green - #caffda
