#' @keywords internal
#'
#' @param timing Whether to print timing of running code? Default is `TRUE`.
#'
#' @importFrom bigassertr stop2
#'
"_PACKAGE"

# The following block is used by usethis to automatically manage
# roxygen namespace tags. Modify with care!
## usethis namespace: start
## usethis namespace: end
NULL
