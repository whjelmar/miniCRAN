library(testthat)
library(runonce)

test_check("runonce")
