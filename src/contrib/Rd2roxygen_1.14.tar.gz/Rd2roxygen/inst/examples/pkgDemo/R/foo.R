foo = function(a, b) {
    NULL
}

## you can use either <- or = to assign values to functions

