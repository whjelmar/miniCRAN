"bar" <- function(a, b) {
    NULL
}
## you can use any of these quotes: `, " or ' to quote the function name
