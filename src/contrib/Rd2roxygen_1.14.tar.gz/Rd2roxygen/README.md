# Rd2roxygen

<!-- badges: start -->
[![R-CMD-check](https://github.com/yihui/Rd2roxygen/workflows/R-CMD-check/badge.svg)](https://github.com/yihui/Rd2roxygen/actions)
[![Downloads from the RStudio CRAN mirror](https://cranlogs.r-pkg.org/badges/Rd2roxygen)](https://cran.r-project.org/package=Rd2roxygen)
<!-- badges: end -->

Convert Rd to roxygen documentation. For more information, see <https://yihui.org/Rd2roxygen>.

