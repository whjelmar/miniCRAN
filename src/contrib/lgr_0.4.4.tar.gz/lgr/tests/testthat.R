library(testthat)
library(lgr)

test_check("lgr")
