extern "C"
{
  SEXP gmpMatToListZ(SEXP X, SEXP line);

  SEXP gmpMatToListQ(SEXP X, SEXP line);
  
}
