# gggibbous 0.1.1

* Updated vignette and README to cite Robert Kosara's related work

* vdiffr is now called conditionally in tests so as to avoid issues on platforms
  that do not have X11

# gggibbous 0.1.0

* Initial release