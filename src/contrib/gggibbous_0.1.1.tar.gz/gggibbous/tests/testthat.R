library(testthat)
library(gggibbous)

test_check("gggibbous")
