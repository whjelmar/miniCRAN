# test add_end_activity on eventlog fails with invalid arg `label`

    `label` must be a <character>.
    x You supplied a <numeric>: 1

---

    Invalid `label`.
    x Activity "check-out" is already present in log. Please use another label.

