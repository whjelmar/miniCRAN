library(testthat)
library(bupaR)
library(eventdataR)

test_check("bupaR")

