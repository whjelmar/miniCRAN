#' @title Grouped eventlog object
#' @name grouped_eventlog
#' @docType class
#' @description Lorem ipsum
#'
NULL