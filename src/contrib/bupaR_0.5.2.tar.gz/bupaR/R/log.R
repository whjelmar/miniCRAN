#' @title Log object
#' @name log
#' @docType class
#' @description Lorem ipsum
#'
NULL
