#' @title Grouped log object
#' @name grouped_log
#' @docType class
#' @description Lorem ipsum
#'
NULL