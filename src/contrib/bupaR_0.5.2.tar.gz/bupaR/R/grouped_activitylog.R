#' @title Grouped activitylog object
#' @name grouped_activitylog
#' @docType class
#' @description Lorem ipsum
#'
NULL