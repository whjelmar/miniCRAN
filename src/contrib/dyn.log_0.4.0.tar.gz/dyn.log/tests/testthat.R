library(testthat)
library(dyn.log)

test_check("dyn.log")
