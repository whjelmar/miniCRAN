core <- c(
"nflfastR",
"nflseedR",
"nfl4th",
"nflreadr",
"nflplotR"
)
