library(testthat)
library(nflverse)

test_check("nflverse")
