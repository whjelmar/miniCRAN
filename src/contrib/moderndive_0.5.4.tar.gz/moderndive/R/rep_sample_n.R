##' @importFrom infer rep_sample_n
##' @export
infer::rep_sample_n
