library(testthat)

test_check("kalmanfilter")

# devtools::spell_check()
# devtools::check_rhub()
# devtools::check_built(paste0("../kalmanfilter_", gsub("Version: ", "", readLines("DESCRIPTION")[which(grepl("Version: ", readLines("DESCRIPTION")))]), ".tar.gz"), args = c("--as-cran", "--no-multiarch"))
# devtools::check_win_devel()
# devtools::release()
