#kalmanfilter 2.0

## Minor changes

* Updated Rcpp code to handle deprecation of << assignment operator

## Major changes

* Updated Rcpp code to handle NULL values for the exogenous and weight matrices
* Updated Rcpp code to handle cases without exogenous coefficient matrices in the state space model
* Removed R wrapper functions
* Added Stock and Watson dynamic common factor model example to the vignette

# kalmanfilter 1.0

## Bug fixes

* none

## Major changes

* Initial release
