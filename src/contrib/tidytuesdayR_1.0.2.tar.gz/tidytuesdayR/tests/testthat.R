library(testthat)
library(tidytuesdayR)

test_check("tidytuesdayR")
