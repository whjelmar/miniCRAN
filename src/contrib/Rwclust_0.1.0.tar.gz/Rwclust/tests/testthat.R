library(testthat)
library(Rwclust)

test_check("Rwclust")
