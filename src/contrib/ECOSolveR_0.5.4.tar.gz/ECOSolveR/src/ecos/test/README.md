## ECOS test problems
This folder contains a set of ECOS test problems in Matlab. To run the
tests, type RUN_ALL_TESTS at the Matlab prompt.

## Future TODO
We may consider some test problems transformed by 
[QCML](http://github.com/cvxgrp/qcml) into C code. The optimal values can
be compared against Matlab (for some problems, at least).
