This folder contains the QCML code (in python) used to generate
some of the test cases.

Normally, one would not need to modify these scripts. They are
here as documentation for the sort of test cases we have been
running.

QCML can be obtained from

    github.com/cvxgrp/qcml
