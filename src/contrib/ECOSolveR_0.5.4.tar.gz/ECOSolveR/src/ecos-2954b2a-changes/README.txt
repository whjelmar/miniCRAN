
This directory is the list of changes to be applied to the release
sources for ecos for use with R; just copy the files here over the
source tree.
