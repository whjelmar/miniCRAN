library(testthat)
library(ECOSolveR)
library(Matrix)

test_check("ECOSolveR")
