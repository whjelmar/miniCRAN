library(testthat)
library(metR)
# library(vdiffr)

test_check("metR")
