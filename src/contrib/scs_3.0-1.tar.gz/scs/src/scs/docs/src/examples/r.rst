.. _r_example:

R
=
TODO
