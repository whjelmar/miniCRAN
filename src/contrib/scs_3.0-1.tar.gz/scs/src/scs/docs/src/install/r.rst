.. _r_install:

R
=
TODO
