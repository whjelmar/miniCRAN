.. _r_interface:

R
=
TODO
