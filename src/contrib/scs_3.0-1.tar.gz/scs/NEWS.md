# scs 3.0-0

- Set `acceleration_lookback` parameter to (current default) `10L`
  from previous value of `20L`.
- Fixed up flags for compiling with Oracle Developer Studio
  compilers.
- Edited and cleaned up `test_socp` which had copy of `test_psd`
  repeated.

# scs 1.3-1

- Synced up to version scs-2.1.1 C library.
