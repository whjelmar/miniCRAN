library(testthat)
library(scs)
library(slam)
test_check("scs")
