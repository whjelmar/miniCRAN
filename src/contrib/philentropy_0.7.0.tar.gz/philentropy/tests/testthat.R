library(testthat)
library(philentropy)

test_check("philentropy")
