## ----eval = F------------------------------------------------------------
#  performance_dashboard(eventlog)
#  resource_dashboard(eventlog)
#  rework_dashboard(eventlog)
#  activity_dashboard(eventlog)

