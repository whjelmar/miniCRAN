#' @keywords internal
"_PACKAGE"

# Suppress R CMD check note
#' @importFrom ggplot2 ggplot
#' @importFrom readr read_csv
#' @importFrom tibble tibble
NULL

# The following block is used by usethis to automatically manage
# roxygen namespace tags. Modify with care!
## usethis namespace: start
## usethis namespace: end
NULL
