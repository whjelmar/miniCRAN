# print module generator

    Code
      print(mod)
    Output
      <luz_module_generator>

