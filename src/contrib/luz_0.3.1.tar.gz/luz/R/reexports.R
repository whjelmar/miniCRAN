#' @importFrom generics fit
#' @export
generics::fit
