library(testthat)
library(KMunicate)

test_check("KMunicate")
