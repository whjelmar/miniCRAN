suppressPackageStartupMessages({
  library(testthat)
  library(httptest)
  library(checkmate)
  library(ffscrapr)
})

test_check("ffscrapr")
