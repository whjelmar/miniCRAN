#' @keywords internal
"_PACKAGE"

# The following block is used by usethis to automatically manage
# roxygen namespace tags. Modify with care!
## usethis namespace: start
#' @import data.table
#' @importFrom ggplot2 element_grob
#' @import grid
#' @importFrom magrittr %>%
#' @importFrom rlang .data %||%
## usethis namespace: end
NULL
