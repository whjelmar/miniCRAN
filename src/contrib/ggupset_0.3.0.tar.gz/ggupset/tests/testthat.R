library(testthat)
library(ggupset)

test_check("ggupset")
