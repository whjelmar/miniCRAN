library(testthat)
library(ggip)

test_check("ggip")
