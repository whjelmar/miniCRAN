# input validation

    Problem while computing stat.
    i Error occurred in the 1st layer.
    Caused by error in `compute_layer()`:
    ! ggip plots require `coord_ip()`.

---

    Problem while computing stat.
    i Error occurred in the 1st layer.
    Caused by error in `compute_layer()`:
    ! The ip aesthetic of `stat_summary_address()` must be an <ip_address/vctrs_rcrd/vctrs_vctr> object.
    x You supplied an <ip_network_coords/vctrs_rcrd/vctrs_vctr> object.

---

    Problem while computing stat.
    i Error occurred in the 1st layer.
    Caused by error in `compute_layer()`:
    ! `stat_summary_address()` requires an ip aesthetic.

---

    Problem while computing stat.
    i Error occurred in the 1st layer.
    Caused by error in `compute_layer()`:
    ! `stat_summary_address()` requires an ip aesthetic.

---

    Problem while computing stat.
    i Error occurred in the 1st layer.
    Caused by error in `compute_layer()`:
    ! The ip aesthetic of `stat_summary_address()` must map to a `data` variable.

---

    Problem while computing stat.
    i Error occurred in the 1st layer.
    Caused by error in `compute_layer()`:
    ! `stat_summary_address()` requires a z aesthetic when using the `fun` argument.

