# input validation

    Problem while converting geom to grob.
    i Error occurred in the 1st layer.
    Caused by error in `draw_panel()`:
    ! ggip plots require `coord_ip()`.

---

    Problem while converting geom to grob.
    i Error occurred in the 1st layer.
    Caused by error in `draw_panel()`:
    ! The ip aesthetic of `geom_hilbert_outline()` must be an <ip_network/vctrs_rcrd/vctrs_vctr> object.
    x You supplied an <ip_address_coords/vctrs_rcrd/vctrs_vctr> object.

---

    Problem while converting geom to grob.
    i Error occurred in the 1st layer.
    Caused by error in `draw_panel()`:
    ! `geom_hilbert_outline()` only works with `coord_ip(curve = "hilbert")`.

