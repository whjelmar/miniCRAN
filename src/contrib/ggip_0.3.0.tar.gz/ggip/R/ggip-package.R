#' @keywords internal
#' @import ipaddress
#' @import rlang
"_PACKAGE"

## usethis namespace: start
#' @importFrom Rcpp sourceCpp
#' @useDynLib ggip, .registration = TRUE
#' @importFrom dplyr %>%
## usethis namespace: end
NULL
