library(testthat)
library(parallelPlot)

test_check("parallelPlot")
