#' time features example: IBM and Microsoft Close Prices
#'
#' A data frame with with daily with daily prices for IBM and Microsoft since March 2017.
#'
#' @format A data frame with 2 columns and 1324 rows.
#'
#' @source finance.yahoo.com
#'
"time_features"
