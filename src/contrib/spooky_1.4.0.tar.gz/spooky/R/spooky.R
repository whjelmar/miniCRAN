#' spooky: automatic jack-knife of spectral analysis for time feature extrapolation
#'
#' Automatic jack-knife of spectral analysis for time feature extrapolation
#'
#' @docType package
#' @name spooky
"_PACKAGE"
