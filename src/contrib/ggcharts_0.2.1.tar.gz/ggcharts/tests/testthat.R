library(testthat)
library(ggcharts)

test_check("ggcharts")
