library(testthat)
library(ggpval)

test_check("ggpval")
