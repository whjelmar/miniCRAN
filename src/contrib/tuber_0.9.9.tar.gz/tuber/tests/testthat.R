library(testthat)
library(tuber)

test_check("tuber")
