library(testthat)
library(tidytable)

test_check("tidytable")
