## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(eval = FALSE)

## -----------------------------------------------------------------------------
#  data_to_json <- function(data) {
#    jsonlite::toJSON(data, dataframe = "rows", auto_unbox = FALSE, rownames = TRUE)
#  }
#  
#  r2d3(data = data_to_json(x), script = "barchart.js")

## -----------------------------------------------------------------------------
#  as_d3_data.igraph <- function(x, ...) {
#    # code to serialize igraph to D3 network friendly JSON
#  }

