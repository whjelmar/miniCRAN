
#' @importFrom htmlwidgets sizingPolicy
#' @export
htmlwidgets::sizingPolicy

#' @importFrom jsonlite read_json
#' @export
jsonlite::read_json