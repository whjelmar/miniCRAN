# ggpolypath 0.2.0

* Updated use of 'size' aesthetic to 'linewidth' in line with ggplot2 instructions: https://www.tidyverse.org/blog/2022/08/ggplot2-3-4-0-size-to-linewidth/ see issue #6. 

# ggpolypath 0.1.0

* First release. 

* Distilled from longer discussion about polygons in https://github.com/r-gris/polyggon

* Ported from 'geom_holygon', listed online at http://rpubs.com/kohske/3522
