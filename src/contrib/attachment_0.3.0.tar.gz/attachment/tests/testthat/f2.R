library(find.me)
require(findme1)
require(   findme2   )
library(findme3)
library(   findme4   )
requireNamespace(findme5)
requireNamespace(     findme6      )


require("findme1a")
require(   "findme2a"   )
library("findme3a")
library(   "findme4a"   )
requireNamespace("findme5a")
requireNamespace(     "findme6a"      )



# require(dontfindme1)
# require(   dontfindme2   )
# library(dontfindme3)
# library(   dontfindme4   )
# requireNamespace(dontfindme5)
# requireNamespace(     dontfindme6      )
#
#
# require("dontfindme1a")
# require(   "dontfindme2a"   )
# library("dontfindme3a")
# library(   "dontfindme4a"   )
# requireNamespace("dontfindme5a")
# requireNamespace(     "dontfindme6a"      )


1+1# require(dontfindme1)
1+1# require(   dontfindme2   )
1+1# library(dontfindme3)
1+1# library(   dontfindme4   )
1+1# requireNamespace(dontfindme5)
1+1# requireNamespace(     dontfindme6      )
1+1#
1+1#
1+1# require("dontfindme1a")
1+1# require(   "dontfindme2a"   )
1+1# library("dontfindme3a")
1+1# library(   "dontfindme4a"   )
1+1# requireNamespace("dontfindme5a")
1+1# requireNamespace(     "dontfindme6a"      )

# Do not find base
base::length(1)
