library(testthat)
library(attachment)

test_check("attachment")
