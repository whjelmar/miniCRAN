# list all global variables
globalVariables(".")
