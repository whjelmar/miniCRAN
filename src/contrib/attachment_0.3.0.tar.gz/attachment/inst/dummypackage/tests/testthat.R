library(testthat)
library(dummypackage)

test_check("dummypackage")
