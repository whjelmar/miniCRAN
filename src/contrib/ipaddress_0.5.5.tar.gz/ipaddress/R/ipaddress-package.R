#' @keywords internal
#' @import rlang
"_PACKAGE"

#' Internal vctrs methods
#'
#' @import vctrs
#' @keywords internal
#' @name ipaddress-vctrs
NULL

# The following block is used by usethis to automatically manage
# roxygen namespace tags. Modify with care!
## usethis namespace: start
#' @useDynLib ipaddress, .registration = TRUE
#' @importFrom Rcpp sourceCpp
## usethis namespace: end
NULL
