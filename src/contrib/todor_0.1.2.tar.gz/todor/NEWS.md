# todor

## 0.1.2

* Added argument to generate markdown output.
* Added argument to return markers to the list.
* Documentation rebuilt and new tests added.


## 0.1.1

* Add possibility to search only the currently active file.
* A modal dialog is now displayed instead of an error message when not in a project.
* renv files are now excluded by default. To include them set the option "todor_exclude_renv" to FALSE.
