library(testthat)
library(todor)

test_check("todor")
