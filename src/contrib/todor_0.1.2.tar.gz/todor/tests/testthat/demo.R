simple_function <- function(a, b) {
  # BUG something is wrong here
  x <- b + 1
  # TODO in the future it should be multiplication
  a + x
}
