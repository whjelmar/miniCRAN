library(testthat)
library(fusen)

test_check("fusen")
