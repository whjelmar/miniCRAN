globalVariables(unique(c(
  # add_fun_code_examples
  ".",
  # add_fun_to_parsed
  "fun_name", "rox_filename", "chunk_filename", ".",
  # get_functions
  ".",
  # split_rmd
  "type", "lines", "title"
)))
