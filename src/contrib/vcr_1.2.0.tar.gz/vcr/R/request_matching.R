#' vcr request matching
#'
#' There are a number of options, some of which are on by default, some of
#' which can be used together, and some alone.
#'
#' @includeRmd man/rmdhunks/request-matching-vignette.Rmd
#'
#' @name request-matching
NULL
