#ifndef _MOVMF_H
#define _MOVMF_H

void mycfG(int *len, double *z, double *n, double *y);
void mycfP(int *len, double *z, double *n, double *y);
void my0F1(int *n, double *x, double *nu, double *y0, double *y);
void rW(int *n, double *kappa, int *m, double *y);

#endif
