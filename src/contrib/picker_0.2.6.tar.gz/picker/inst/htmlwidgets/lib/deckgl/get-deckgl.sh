#!/bin/sh

wget https://unpkg.com/deck.gl@8.5.7/dist.min.js
