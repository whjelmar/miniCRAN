library(testthat)
library(chronicler)

test_check("chronicler")
