utils::globalVariables(c("outcome"))
