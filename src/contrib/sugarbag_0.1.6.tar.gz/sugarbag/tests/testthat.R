library(testthat)
library(sugarbag)

test_check("sugarbag")
