library(testthat)
library(rosm)

test_check("rosm")
