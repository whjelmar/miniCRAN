library(testthat)

library(ggplot2)
library(ggpackets)

test_check("ggpackets")
