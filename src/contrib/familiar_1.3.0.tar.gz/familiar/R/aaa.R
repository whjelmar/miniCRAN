# Environment holding global variables and settings.
familiar_global_env <- new.env(parent=emptyenv())
