library(testthat)
library(tidyxl)

test_check("tidyxl")
