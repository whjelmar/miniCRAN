library(testthat)
library(rfm)

test_check("rfm")
