library(testthat)
library(RandomForestsGLS)

test_check("RandomForestsGLS")
