library(testthat)
library(reactable)

test_check("reactable")
