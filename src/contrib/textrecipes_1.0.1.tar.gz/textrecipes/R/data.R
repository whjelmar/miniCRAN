#' Sample sentences with emojis
#'
#' This data set is primarily used for examples.
#'
#' @format tibble with 1 column
"emoji_samples"
