library(testthat)
library(textrecipes)

test_check("textrecipes")
