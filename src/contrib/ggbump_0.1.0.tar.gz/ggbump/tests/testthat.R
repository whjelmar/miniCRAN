library(testthat)
library(ggbump)

test_check("ggbump")
