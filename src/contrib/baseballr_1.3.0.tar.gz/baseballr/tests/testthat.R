library(testthat)
library(baseballr)

test_check("baseballr")
