#' ggeasy.
#'
#' Helper functions for making using ggplot2 easier.
#'
#' @name ggeasy
#' @import ggplot2
#' @docType package
NULL
