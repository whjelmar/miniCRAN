library(testthat)
library(ggeasy)

test_check("ggeasy")
