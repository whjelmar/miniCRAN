#' @keywords package
"_PACKAGE"

globalVariables(".")

#' @import rlang
#' @import tsibble
#' @import vctrs
#' @importFrom dplyr mutate transmute summarise group_by ungroup filter distinct lead
#' @importFrom tidyr gather
NULL

