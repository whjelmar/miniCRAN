#' Multilevel example Network
#' @description Multilevel network, where both levels have different structural features

#' @format igraph object
"multilvl_ex"
