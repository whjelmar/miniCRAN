utils::globalVariables(
    names = c(
        "new_data", "object", ".actual", ".fitted", "fail_check", ".row_id", "value", "id", "python"
    )
)
