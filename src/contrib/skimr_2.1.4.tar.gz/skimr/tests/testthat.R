library(testthat)
library(skimr)

test_check("skimr")
