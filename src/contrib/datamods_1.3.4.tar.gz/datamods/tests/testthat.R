library(testthat)
library(datamods)

test_check("datamods")
