library(testthat)
library(proceduralnames)

test_check("proceduralnames")
