#' @importFrom stringr str_detect
#' @importFrom stringr str_subset
#' @importFrom stringr str_which
#' @importFrom stringr str_count
#' @importFrom stringr str_extract str_extract_all
#' @importFrom stringr str_match str_match_all
#' @importFrom stringr str_replace str_replace_all
#' @importFrom stringr str_locate str_locate_all
NULL
