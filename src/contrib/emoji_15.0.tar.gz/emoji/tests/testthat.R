library(testthat)
library(emoji)

test_check("emoji")
