# guide_axis_logticks errors upon misuse

    Guide `axis` cannot be used for colour.

