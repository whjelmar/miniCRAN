# geom_outline_point draws outlines

    Code
      pnl[[1]]$col
    Output
      [1] "#CB4D42" "#00989D"

---

    Code
      pnl[[2]]$col
    Output
      [1] "#F8766D" "#00BFC4"

