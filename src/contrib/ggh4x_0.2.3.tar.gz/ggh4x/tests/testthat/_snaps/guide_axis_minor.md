# guide_axis_minor errors upon misuse

    Guide `axis` cannot be used for colour.

