# try_require returns error when package is absent

    The package `nonsense` is required for `test`.

