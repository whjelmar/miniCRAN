# This package is based on the tidyverse package, hence the copyright
# attribution to RStudio.

#' @keywords internal
"_PACKAGE"

NULL
