# findInFiles

<!-- badges: start -->
[![R-CMD-check](https://github.com/stla/findInFiles/workflows/R-CMD-check/badge.svg)](https://github.com/stla/findInFiles/actions)
<!-- badges: end -->


![](https://raw.githubusercontent.com/stla/findInFiles/main/inst/screenshots/findInFiles.gif)

As of version 0.4.0, a Shiny app is provided:

![](https://raw.githubusercontent.com/stla/findInFiles/main/inst/screenshots/shiny.gif)
