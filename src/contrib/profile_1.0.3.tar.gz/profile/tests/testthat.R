library(testthat)
library(profile)

test_check("profile")
