.onAttach <-
function (libname, pkgname){
   # echo output to screen
   packageStartupMessage("## See bit.ly/panelview4r for more info.\n## Report bugs -> yiqingxu@stanford.edu.\n")
}
