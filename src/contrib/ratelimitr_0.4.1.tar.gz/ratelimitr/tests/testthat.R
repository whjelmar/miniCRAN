library(testthat)
library(ratelimitr)

test_check("ratelimitr")
